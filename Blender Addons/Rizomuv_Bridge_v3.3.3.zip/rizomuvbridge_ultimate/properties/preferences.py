"""Custom addon preferences."""

import logging

from bpy.types import AddonPreferences

from .. import addon_constants
from .autoseams_preferences import AutoseamsPreferences
from .config_preferences import ConfigPreferences
from .export_preferences import ExportPreferences
from .gui_preferences import GuiPreferences
from .import_preferences import ImportPreferences
from .rizom_preferences import RizomPreferences

logger = logging.getLogger(__name__)


class RizomBridgePreferences(
    AddonPreferences,
    ConfigPreferences,
    GuiPreferences,
    ExportPreferences,
    ImportPreferences,
    RizomPreferences,
    AutoseamsPreferences,
):
    bl_idname = addon_constants.PACKAGE
