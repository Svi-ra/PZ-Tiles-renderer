"""Main addon module."""

import logging

import bpy
from bpy.props import PointerProperty
from bpy.types import WindowManager

from . import operators, ui
from .file_access import ensure_data_dir_integrity
from .properties.preferences import RizomBridgePreferences
from .properties.property_groups import RizomBridgeGuiTabs, RizomBridgeUVMaps
from .utils import addon_utils, rizom_utils
from .utils.hooks.usd_hook import UsdHookRizom
from .utils.update_callbacks import logging_toggle

logger = logging.getLogger(__name__)


PROPERTIES = (RizomBridgePreferences, RizomBridgeUVMaps, RizomBridgeGuiTabs)
MODULES = (operators, ui)

ensure_data_dir_integrity()


def register():
    """Register addon.

    Properties need to be registered first so operators and panels can access them.

    """
    bpy.utils.register_class(UsdHookRizom)  # type: ignore

    for prop in PROPERTIES:
        bpy.utils.register_class(prop)

    for module in MODULES:
        module.register()

    setattr(WindowManager, "RizomBridgeGuiTabs", PointerProperty(type=RizomBridgeGuiTabs))
    setattr(WindowManager, "RizomBridgeUVMaps", PointerProperty(type=RizomBridgeUVMaps))

    prefs = addon_utils.get_prefs()

    # Set the initial logging output state.
    logging_toggle(prefs.enable_logging, logger)

    # Set the initial RizomUVLink availability based on the Rizom path.
    prefs.use_livelink = rizom_utils.check_for_livelink(prefs.rizom_path)


def unregister():
    """Unregister addon.

    Properties need to be unregistered last so operators and panels can access them.

    """
    bpy.utils.unregister_class(UsdHookRizom)  # type: ignore

    for module in MODULES:
        module.unregister()

    delattr(WindowManager, "RizomBridgeGuiTabs")
    delattr(WindowManager, "RizomBridgeUVMaps")

    for prop in PROPERTIES:
        bpy.utils.unregister_class(prop)
