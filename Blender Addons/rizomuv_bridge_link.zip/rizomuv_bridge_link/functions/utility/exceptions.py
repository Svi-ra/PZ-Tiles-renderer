class InvalidRizomVersion(Exception):
    """Custom exception for wrong Rizom version."""

    def __init__(self, message="This version is for Rizom 2023+, please install one of the legacy files."):
        self.message = message
        super().__init__(self.message)