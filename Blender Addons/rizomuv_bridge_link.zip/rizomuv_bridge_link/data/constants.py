"""Constant values."""

from pathlib import Path

AUTOSEAMS = ["AUTOSEAMS_SHARP_EDGES", "AUTOSEAMS_MOSAIC", "AUTOSEAMS_PELT", "AUTOSEAMS_BOX"]

GUI_STRINGS = Path(__file__).parents[1] / "resources" / "json" / "gui_strings.json"

FBX_PATH = Path(__file__).parent / "transfer_meshes" / "rizom_transfer.fbx"
OBJ_PATH = Path(__file__).parent / "transfer_meshes" / "rizom_transfer.obj"

PACKAGE_NAME = Path(__file__).parents[1].name

PORT = Path(__file__).parent / "rizom_port.txt"