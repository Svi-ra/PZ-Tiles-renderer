"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: ops/material.py
# brief: Material operators
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import bpy

from ..api import SUBSTANCE_Api
from ..utils import SUBSTANCE_Utils


class SUBSTANCE_OT_Version(bpy.types.Operator):
    bl_idname = 'substance.version'
    bl_label = 'Version'
    bl_description = 'Get the current plugin version'

    def execute(self, context):
        _version = SUBSTANCE_Api.version()

        SUBSTANCE_Utils.log_data(
            "INFO",
            "Substance Addon version {}.{}.{}".format(_version[0], _version[1], _version[2]),
            display=True)

        return {'FINISHED'}


class SUBSTANCE_OT_Message(bpy.types.Operator):
    bl_idname = 'substance.send_message'
    bl_label = 'Message'
    bl_description = "Send the user a message"

    type: bpy.props.StringProperty(default="INFO") # noqa
    message: bpy.props.StringProperty(default="") # noqa
    _timer = None

    def modal(self, context, event):
        if event.type == 'TIMER':
            self.cancel(context)
            self.report({self.type}, self.message)
            return {'FINISHED'}
        return {'PASS_THROUGH'}

    def execute(self, context):
        wm = context.window_manager
        self._timer = wm.event_timer_add(time_step=1, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        wm = context.window_manager
        wm.event_timer_remove(self._timer)
