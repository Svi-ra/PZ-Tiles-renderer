"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: ops/connector.py
# brief: Material operators
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.

import bpy

from ..api import SUBSTANCE_Api
from ..utils import SUBSTANCE_Utils
from ..sbsar.sbsar import SBSAR
from ..thread_ops import SUBSTANCE_Threads
from ..sbsar.async_ops import _render_sbsar
from ..sbsar.sbsar import SBS_Preset
from ..common import (
    PRESET_DEFAULT,
    PRESET_CUSTOM,
    Code_Response,
    Code_RequestType
)


def load_sbsar(filename, filepath, uuid=None, type=Code_RequestType.r_async):
    _addon_prefs, _selected_shader_idx, _selected_shader_preset = SUBSTANCE_Utils.get_selected_shader(bpy.context)
    _normal_format = _addon_prefs.default_normal_format
    _output_size = _addon_prefs.default_resolution.get()

    _unique_name = SUBSTANCE_Utils.get_unique_name(filename, bpy.context)

    SUBSTANCE_Utils.log_data("INFO", "Begin loading substance from file [{}]".format(filename), display=True)
    if uuid:
        _data = {
            "uuid": uuid,
            "filepath": filepath,
            "name": _unique_name,
            "$outputsize": _output_size,
            "normal_format": 0 if _normal_format == "DirectX" else 1
        }
    else:
        _data = {
            "filepath": filepath,
            "name": _unique_name,
            "$outputsize": _output_size,
            "normal_format": 0 if _normal_format == "DirectX" else 1
        }

    # Load the sbsar to the SRE
    _result = SUBSTANCE_Api.sbsar_load(_data)
    if _result[0] != Code_Response.success:
        SUBSTANCE_Utils.log_data(
            "ERROR",
            "Substance file [{}] located at [{}] could not be loaded".format(filename, filepath),
            display=True)
        return
    if _result[1]["result"] != Code_Response.success.value:
        SUBSTANCE_Utils.log_data(
            "ERROR",
            "An error ocurred while loading Substance file [{}]. Failed with error [{}]".format(
                filepath, _result[1]["result"]),
            display=True)
        return

    _sbsar = SBSAR(_unique_name, filename, _result[1]["data"], _addon_prefs)
    _loaded_sbsar = bpy.context.scene.loaded_sbsars.add()
    _loaded_sbsar.init(_sbsar)
    _loaded_sbsar.init_shader(_selected_shader_idx, _selected_shader_preset)
    SUBSTANCE_Api.sbsar_register(_sbsar)
    bpy.context.scene.sbsar_index = len(bpy.context.scene.loaded_sbsars) - 1

    if type == Code_RequestType.r_async:
        for _idx, _graph in enumerate(_loaded_sbsar.graphs):
            SUBSTANCE_Threads.alt_thread_run(_render_sbsar, (bpy.context, _loaded_sbsar, _idx))

    SUBSTANCE_Utils.log_data("INFO", "Substance from file [{}] loaded".format(filename))


def load_obj(filename, filepath, uuid=None):
    def load_file():
        bpy.ops.wm.obj_import(filepath=filepath)
        SUBSTANCE_Utils.log_data(
            "INFO",
            "Substance Connector file [{}] loaded".format(filename),
            display=True)
    SUBSTANCE_Threads.main_thread_run(load_file)


def load_fbx(filename, filepath, uuid=None):
    def load_file():
        bpy.ops.import_scene.fbx(filepath=filepath)
        SUBSTANCE_Utils.log_data(
            "INFO",
            "Substance Connector file [{}] loaded".format(filename),
            display=True)
    SUBSTANCE_Threads.main_thread_run(load_file)


def load_usd(filename, filepath, uuid=None):
    def load_file():
        bpy.ops.wm.usd_import(filepath=filepath, relative_path=True, set_material_blend=False)
        SUBSTANCE_Utils.log_data(
            "INFO",
            "Substance Connector file [{}] loaded".format(filename),
            display=True)
    SUBSTANCE_Threads.main_thread_run(load_file)


def load_gltf(filename, filepath, uuid=None):
    def load_file():
        bpy.ops.import_scene.gltf(filepath=filepath)
        SUBSTANCE_Utils.log_data(
            "INFO",
            "Substance Connector file [{}] loaded".format(filename),
            display=True)
    SUBSTANCE_Threads.main_thread_run(load_file)


def load_stl(filename, filepath, uuid=None):
    def load_file():
        bpy.ops.wm.stl_import(filepath=filepath)
        SUBSTANCE_Utils.log_data(
            "INFO",
            "Substance Connector file [{}] loaded".format(filename),
            display=True)
    SUBSTANCE_Threads.main_thread_run(load_file)


def load_preset(filename, filepath, uuid=None):
    def load_file():
        _result = SUBSTANCE_Api.sbsar_preset_read(filepath)
        if _result[0] != Code_Response.success:
            SUBSTANCE_Utils.log_data("ERROR", "[{}] Error while reading preset from file".format(_result))

        _sbsars = bpy.context.scene.loaded_sbsars
        _preset_added = 0
        for _package_url, _new_presets in _result[1].items():
            for _sbsar in _sbsars:
                for _graph in _sbsar.graphs:
                    if _graph.packageUrl != _package_url:
                        continue

                    _preset_added += 1
                    for _preset in _new_presets:
                        if _preset["label"] in _graph.presets:
                            if _preset["label"] == PRESET_CUSTOM or _preset["label"] == PRESET_DEFAULT:
                                SUBSTANCE_Utils.log_data(
                                    "ERROR",
                                    "[{}] Preset [{}] cannot be overwritten".format(
                                        Code_Response.preset_import_protected_error,
                                        _preset["label"]),
                                    display=True)
                                continue

                            for _existing_preset in _graph.presets:
                                if _preset["label"] != _existing_preset.name:
                                    continue
                                if _existing_preset.embedded:
                                    SUBSTANCE_Utils.log_data(
                                        "ERROR",
                                        "[{}] Error [{}] cannot be overwritten".format(
                                            Code_Response.preset_import_protected_error,
                                            _preset["label"]),
                                        display=True)
                                    continue

                                _existing_preset.value = _preset["value"]
                                SUBSTANCE_Utils.log_data(
                                    "INFO",
                                    "Preset [{}] updated.".format(_preset["label"]),
                                    display=True)
                        else:
                            _item = {
                                "index": len(_graph.presets),
                                "label": _preset["label"],
                                "embedded": False,
                                "icon": "LOCKED",
                                "value": _preset["value"]
                            }
                        _preset = SBS_Preset(_item)
                        _new_preset = _graph.presets.add()
                        _new_preset.init(_preset)

                        SUBSTANCE_Utils.log_data(
                            "INFO",
                            "Preset [{}] imported.".format(_preset.label),
                            display=True)

        if _preset_added == 0:
            SUBSTANCE_Utils.log_data(
                "ERROR",
                "[{}] - No substance graph matches any of the presets availabe in the file [{}]".format(
                    Code_Response.preset_import_not_graph,
                    filepath),
                display=True)
    SUBSTANCE_Threads.main_thread_run(load_file)
