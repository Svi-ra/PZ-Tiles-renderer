"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: ops/inputs.py
# brief: Parameter Operators
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import bpy
from random import randint

from ..utils import SUBSTANCE_Utils
from ..common import INPUTS_MAX_RANDOM_SEED, Code_InputIdentifier


class SUBSTANCE_OT_RandomizeSeed(bpy.types.Operator):
    bl_idname = 'substance.randomize_seed'
    bl_label = 'Randomize'
    bl_description = 'Generate a new random value for the current SBSAR randomseed parameter'

    def execute(self, context):

        _selected_graph = SUBSTANCE_Utils.get_selected_graph(context)
        _parms = getattr(context.scene, _selected_graph.inputs_class_name)
        _value = randint(0, INPUTS_MAX_RANDOM_SEED)
        setattr(_parms, Code_InputIdentifier.randomseed.value, _value)

        return {'FINISHED'}


class SUBSTANCE_OT_InputGroupsCollapse(bpy.types.Operator):
    bl_idname = 'substance.input_groups_collapse'
    bl_label = 'Collapse Groups'
    bl_description = 'Collapse all groups'

    def execute(self, context):

        _selected_graph = SUBSTANCE_Utils.get_selected_graph(context)
        for _group in _selected_graph.input_groups:
            _group.collapsed = True

        return {'FINISHED'}


class SUBSTANCE_OT_InputGroupsExpand(bpy.types.Operator):
    bl_idname = 'substance.input_groups_expand'
    bl_label = 'Expand Groups'
    bl_description = 'Expand all groups'

    def execute(self, context):

        _selected_graph = SUBSTANCE_Utils.get_selected_graph(context)
        for _group in _selected_graph.input_groups:
            _group.collapsed = False

        return {'FINISHED'}
