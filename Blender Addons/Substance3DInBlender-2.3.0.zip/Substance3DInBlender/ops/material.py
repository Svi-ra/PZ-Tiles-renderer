"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: ops/material.py
# brief: Material operators
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import bpy
import json
import traceback

from ..utils import SUBSTANCE_Utils
from ..common import Code_SbsarLoadSuffix
from ..material.manager import SUBSTANCE_MaterialManager


class SUBSTANCE_OT_SetMaterial(bpy.types.Operator):
    bl_idname = 'substance.set_material'
    bl_label = 'Set material'
    bl_description = "Set the material shader network"

    data: bpy.props.StringProperty(default="") # noqa

    def execute(self, context):
        _data = json.loads(self.data)

        if len(_data["outputs"]) == 0:
            SUBSTANCE_Utils.log_data("INFO", "No render changes")
            return {'FINISHED'}

        _sbsar = None
        for _item in context.scene.loaded_sbsars:
            if _item.uuid == _data["uuid"]:
                _sbsar = _item

        if _sbsar is None:
            SUBSTANCE_Utils.log_data("ERROR", "Substance file cannot be found", display=True)
            return {'FINISHED'}

        try:
            _graph = None
            for _item in _sbsar.graphs:
                _uid = str(_data["graph_uid"])
                if _uid == _item.uid:
                    _graph = _item
                    break

            if _graph is None:
                SUBSTANCE_Utils.log_data("ERROR", "Substance graph cannot be found", display=True)
                return {'FINISHED'}

            _graph.set_thumbnail(_data)

            _outputs = {}
            for _output in _data["outputs"]:
                if _output["usage"] == "UNKNOWN":
                    _outputs[_output["identifier"]] = _output
                else:
                    _outputs[_output["usage"]] = _output
            _data["outputs"] = _outputs

            SUBSTANCE_MaterialManager.create_shader_network(context, _sbsar, _graph, _data)

        except Exception:
            _sbsar.suffix = Code_SbsarLoadSuffix.error.value[0]
            _sbsar.icon = Code_SbsarLoadSuffix.error.value[1]
            SUBSTANCE_Utils.log_data("ERROR", "Exception - Susbtance material creation error:")
            SUBSTANCE_Utils.log_traceback(traceback.format_exc())

        return {'FINISHED'}
