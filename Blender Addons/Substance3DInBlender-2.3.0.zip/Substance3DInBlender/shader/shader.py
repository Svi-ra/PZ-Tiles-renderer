"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: shader/shader.py
# brief: Shader preset class object definition
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


from ..common import CLASS_SHADER_INPUTS


class ShaderPreset_Output():
    def __init__(self, output):
        self.id = output["id"]
        self.label = output["label"]
        self.enabled = output["enabled"]
        self.optional = output["optional"]
        self.colorspace = output["colorspace"]
        self.format = output["format"]
        self.bitdepth = output["bitdepth"]
        self.normal = output["normal"] if "normal" in output else False
        if "node_type" in output:
            self.node_type = output["node_type"]
        else:
            self.node_type = ""
        self.gamma = 1.0
        if "gamma" in output:
            self.gamma = output["gamma"]

    def to_json(self):
        _obj = {
            "id": self.id,
            "label": self.label,
            "enabled": self.enabled,
            "optional": self.optional,
            "colorspace": self.colorspace,
            "format": self.format,
            "bitdepth": self.bitdepth,
            "node_type": self.node_type,
            "gamma": self.gamma
        }
        if self.normal:
            _obj["normal"] = True
        return _obj


class ShaderPreset_GenericOutput():
    def __init__(self, output):
        self.enabled = output["enabled"]
        self.colorspace = output["colorspace"]
        self.format = output["format"]
        self.bitdepth = output["bitdepth"]
        self.node_type = output["node_type"]

    def to_json(self):
        _obj = {
            "enabled": self.enabled,
            "colorspace": self.colorspace,
            "format": self.format,
            "bitdepth": self.bitdepth,
            "node_type": self.node_type
        }
        return _obj


class ShaderPreset_Input():
    def __init__(self, input):
        self.id = input["id"]
        self.label = input["label"]
        self.type = input["type"]
        self.default = input["default"]
        self.min = input["min"] if "min" in input else None
        self.max = input["max"] if "max" in input else None

    def to_json(self):
        _obj = {
            "id": self.id,
            "label": self.label,
            "type": self.type,
            "default": self.default
        }
        if self.min is not None:
            _obj["min"] = self.min
        if self.max is not None:
            _obj["max"] = self.max
        return _obj


class ShaderPreset():
    def __init__(self, filename, data):
        self.filename = filename
        self.name = filename.replace(".json", "")
        self.label = data["label"]
        self.rndr = data["rndr"]
        self.default_output = ShaderPreset_GenericOutput(data["default_output"])

        self.inputs = {}
        self.outputs = {}
        self.inputs_class_name = CLASS_SHADER_INPUTS.format(filename.replace(".json", "").replace(" ", "_"))

        for _key, _input in data["inputs"].items():
            _item = ShaderPreset_Input(_input)
            self.inputs[_key] = _item

        for _key, _output in data["outputs"].items():
            _item = ShaderPreset_Output(_output)
            self.outputs[_key] = _item

    def to_json(self):
        _obj = {
            "label": self.label,
            "rndr": self.rndr,
            "default_output": {
                "enabled": self.default_output.enabled,
                "colorspace": self.default_output.colorspace,
                "format": self.default_output.format,
                "bitdepth": self.default_output.bitdepth,
                "node_type": self.default_output.node_type
            },
            "inputs": {},
            "outputs": {},
            "inputs_class_name": self.inputs_class_name
        }

        for _key, _input in self.inputs.items():
            _obj["inputs"][_key] = _input.to_json()

        for _key, _output in self.outputs.items():
            _obj["outputs"][_key] = _output.to_json()

        return _obj
