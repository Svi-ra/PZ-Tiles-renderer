"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: render.py
# brief: Async comms handler
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


from ..network.callback import SRE_CallbackInterface
from ..api import SUBSTANCE_Api
from ..common import Code_CallbackEndpoint as endpoint


class Server_POST_Render(SRE_CallbackInterface):
    def execute(self, message):
        if message["type"] != endpoint.render.value:
            return
        _data = message["data"]
        for _output in _data["outputs"]:
            if "path" in _output:
                _new_path = _output["path"].replace("\\", "/")
                _output["path"] = _new_path

        SUBSTANCE_Api.sbsar_render_callback(_data)
