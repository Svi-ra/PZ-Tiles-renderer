"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: sbsar/async_ops.py
# brief: Asynchronous substance operations
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import os
import bpy
import traceback

from ..utils import SUBSTANCE_Utils
from ..thread_ops import SUBSTANCE_Threads
from ..common import RENDER_KEY, ADDON_PACKAGE


def _render_sbsar(context, sbsar, index):
    _addon_prefs = context.preferences.addons[ADDON_PACKAGE].preferences
    if not os.path.exists(_addon_prefs.path_default):
        os.makedirs(_addon_prefs.path_default)

    from ..api import SUBSTANCE_Api
    _render_id = RENDER_KEY.format(sbsar.uuid, sbsar.graphs[index].index)
    _graph = sbsar.graphs[index]

    _outputs = []
    for _output in _graph.outputs:
        _item = {
            "identifier": _output.identifier,
            "enabled": _output.shader_enabled,
            "format": _output.shader_format,
            "bitdepth": _output.shader_bitdepth
        }
        _outputs.append(_item)

    _data = {
        "uuid": sbsar.uuid,
        "index": index,
        "out_path": _addon_prefs.path_default,
        "outputs": _outputs
    }
    SUBSTANCE_Api.sbsar_render(_render_id, _data)


def _set_input_visibility(sbsar, graph, inputs):
    try:
        def _callback_visibility():
            _selected_sbsar = None
            for _item in bpy.context.scene.loaded_sbsars:
                if _item.uuid == sbsar.uuid:
                    _selected_sbsar = _item
                    break

            if _selected_sbsar is None:
                return

            _graph = _selected_sbsar.graphs[int(graph.index)]
            for _input in inputs:
                if _input["identifier"] in _graph.inputs:
                    _graph.inputs[_input["identifier"]].visibleIf = _input["visibleIf"]

        SUBSTANCE_Threads.main_thread_run(_callback_visibility)

    except Exception:
        SUBSTANCE_Utils.log_data("ERROR", "Exception - Unknown Error while setting parameter visibility:")
        SUBSTANCE_Utils.log_traceback(traceback.format_exc())
