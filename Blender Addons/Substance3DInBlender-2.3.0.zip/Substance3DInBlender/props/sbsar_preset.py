"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: props/sbsar_preset.py
# brief: Substance Property Groups
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import bpy


class SUBSTANCE_PG_SbsarPreset(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="name")
    index: bpy.props.StringProperty(
        name="index",
        description="The index of the preset in the Substance 3D graph") # noqa
    idx: bpy.props.IntProperty(
        name="idx",
        description="The integer index of the preset in the Substance 3D graph") # noqa
    label: bpy.props.StringProperty(
        name="label",
        description="The preset name of the Substance 3D graph") # noqa 
    value: bpy.props.StringProperty(
        name="value",
        description="The preset value of the Substance 3D graph") # noqa 
    icon: bpy.props.StringProperty(
        name="icon",
        description="The preset icon that shows if a preset is editable") # noqa 
    embedded: bpy.props.BoolProperty(
        name="embedded",
        description="The preset origin") # noqa 

    def init(self, preset):
        self.name = preset.label
        self.idx = preset.idx
        self.index = preset.index
        self.label = preset.label
        self.value = preset.value
        self.icon = preset.icon
        self.embedded = preset.embedded

    def get(self):
        return {
            "idx": self.idx,
            "index": self.index,
            "label": self.label,
            "value": self.value,
            "icon": self.icon,
            "embedded": self.embedded
        }
