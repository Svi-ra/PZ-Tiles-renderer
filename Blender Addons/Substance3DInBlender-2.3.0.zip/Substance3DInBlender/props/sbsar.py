"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: props/sbsar.py
# brief: Substance Property Groups
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import bpy
from .sbsar_graph import SUBSTANCE_PG_SbsarGraph

from ..common import (
    Code_SbsarLoadSuffix,
    ADDON_PACKAGE
)


def get_graph_items(self, context):
    _graphs = []
    for _idx, _graph in enumerate(self.graphs):
        _item = (_graph.index, _graph.label, "{}:{}:{}".format(_graph.index, _graph.label, _graph.uid))
        _graphs.append(_item)
    if len(_graphs) == 0:
        return [("0", "NONE", "NONE:NONE:NONE")]
    return _graphs


def on_graph_update(self, context):
    pass


def on_suffix_update(self, context):
    if self.suffix == Code_SbsarLoadSuffix.success.value[0]:
        self.loading = Code_SbsarLoadSuffix.success.value[1]
        self.load_success = True
    elif self.suffix == Code_SbsarLoadSuffix.error.value[0]:
        self.loading = Code_SbsarLoadSuffix.error.value[1]
        self.load_success = False


class SUBSTANCE_PG_Sbsar(bpy.types.PropertyGroup):
    uuid: bpy.props.StringProperty(
        name="uuid",
        description="The ID of the Substance 3D *.sbsar file") # noqa
    version: bpy.props.IntProperty(
        name="version",
        description="The Version of the Substance Engine used by the .sbsar file") # noqa
    name: bpy.props.StringProperty(
        name="name",
        description="The name of the Substance *.sbsar file") # noqa
    filename: bpy.props.StringProperty(
        name='filename',
        description='The name of the *.sbsar file') # noqa
    filepath: bpy.props.StringProperty(
        name='filepath',
        description='The path to the *.sbsar file') # noqa

    graphs: bpy.props.CollectionProperty(type=SUBSTANCE_PG_SbsarGraph)
    graphs_list: bpy.props.EnumProperty(
        name="graphs",
        description="The available graphs of the Substance 3D material", # noqa
        items=get_graph_items,
        update=on_graph_update)

    suffix: bpy.props.StringProperty(
        name="suffix",
        default=Code_SbsarLoadSuffix.loading.value[0],
        update=on_suffix_update)
    icon: bpy.props.StringProperty(
        name="icon",
        default=Code_SbsarLoadSuffix.loading.value[1],
        update=on_suffix_update)

    loading: bpy.props.StringProperty(name="loading", default="TEMP") # noqa
    load_success: bpy.props.BoolProperty(default=False)

    def init(self, sbsar):
        self.uuid = sbsar.uuid
        self.version = sbsar.version
        self.name = sbsar.name
        self.filename = sbsar.filename
        self.filepath = sbsar.filepath

        _addon_prefs = bpy.context.preferences.addons[ADDON_PACKAGE].preferences
        for _graph in sbsar.graphs:
            _new_graph = self.graphs.add()
            _new_graph.init(_graph, _addon_prefs)

    def init_shader(self, shader_idx, shader):
        for _graph in self.graphs:
            _graph.init_shader(shader_idx, shader)

    def init_tiling(self, sbsar):
        for _idx, _graph in enumerate(self.graphs):
            _graph.init_tiling(sbsar.graphs[_idx].tiling.get(), sbsar.graphs[_idx].tiling.linked)

    def init_shader_duplicate(self, sbsar):
        for _idx, _graph in enumerate(self.graphs):
            _graph.init_shader_duplicate(sbsar.graphs[_idx].shaders_list)

    def init_outputs(self, sbsar):
        for _idx, _graph in enumerate(self.graphs):
            _graph.init_outputs(sbsar.graphs[_idx].outputs)

    def init_presets(self, sbsar):
        for _idx, _graph in enumerate(self.graphs):
            _graph.init_preset(sbsar.graphs[_idx].presets_list)

    def get(self):
        _obj = {
            "uuid": self.uuid,
            "version": self.version,
            "name": self.name,
            "filename": self.filename,
            "filepath": self.filepath,
            "graphs": []
        }
        for _graph in self.graphs:
            _obj["graphs"].append(_graph.get())

        return _obj
