"""
Copyright (C) 2023 Adobe.
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# file: material/manager.py
# brief: Material operations manager
# author Adobe - 3D & Immersive
# copyright 2023 Adobe Inc. All rights reserved.


import os
import bpy
import time
import traceback
# from copy import deepcopy

from ..thread_ops import SUBSTANCE_Threads
from ..utils import SUBSTANCE_Utils
from ..common import RENDER_IMG_UPDATE_DELAY_S, ADDON_PACKAGE, Code_Renderer


def get_shader_editor_context():
    for screen in bpy.data.screens:
        for area in screen.areas:
            if area.type == "NODE_EDITOR":
                for space in area.spaces:
                    if space.tree_type == "ShaderNodeTree":
                        context_override = {"area": area, "space": space, "screen": screen}
                        return context_override


class SUBSTANCE_MaterialManager():

    @staticmethod
    def get_image(name, filepath):
        if name in bpy.data.images:
            _image = bpy.data.images[name]
            _image_filepath = bpy.path.abspath(_image.filepath)
            _image_filepath = os.path.abspath(_image_filepath)
            _image_filepath = _image_filepath.replace("\\", "/")
            _new_filepath = filepath.replace("\\", "/")

            if _image_filepath != _new_filepath:
                _image.filepath = _new_filepath
            _image.reload()
            return _image
        _image = bpy.data.images.load(filepath=filepath.replace("\\", "/"))
        _image.name = name
        return _image

    @staticmethod
    def get_existing_material(material_name):
        if material_name in bpy.data.materials:
            return bpy.data.materials[material_name]
        return None

    @staticmethod
    def reset_image(node, image):
        def _set_image():
            node.image = image
        SUBSTANCE_Threads.main_thread_run(_set_image)

    @staticmethod
    def apply_material(context, objects, material):
        _addon_prefs = context.preferences.addons[ADDON_PACKAGE].preferences

        for _obj in objects:
            if not hasattr(_obj.data, "materials"):
                continue
            if _addon_prefs.default_apply_type == "INSERT" and _obj.data.materials:
                # _obj.data.materials.append(material)
                _obj.active_material = material
            else:
                _obj.data.materials.append(material)

    @staticmethod
    def auto_apply_material(context, data, material):
        _selected_geo = SUBSTANCE_Utils.get_selected_geo(context.selected_objects)
        if len(_selected_geo) > 0 and data["graph_idx"] == 0:
            _selected_objects = [bpy.context.active_object]
            SUBSTANCE_MaterialManager.apply_material(context, _selected_objects, material)

    @staticmethod
    def empty_material(material, nodes, graph):
        try:
            material.cycles.displacement_method = 'BOTH'
        except Exception:
            pass

        # Cleanup graph
        for _node in nodes:
            nodes.remove(_node)

    @staticmethod
    def init_base_nodes(nodes, graph, shader_graph):
        _items = {}
        for _node in shader_graph["nodes"]:
            _name = _node["name"].replace("$matname", graph.material.name)

            if _name in nodes:
                _items[_node["id"]] = nodes[_name]
            else:
                _items[_node["id"]] = nodes.new(_node["type"])
                _items[_node["id"]].name = _name
                if _node["type"] == "NodeFrame":
                    _items[_node["id"]].label = _node["label"]
                    continue
            if "location" in _node:
                _items[_node["id"]].location = (_node["location"][0], _node["location"][1])
        return _items

    @staticmethod
    def clean_sbsar_nodes(nodes):
        for _node in nodes:
            if _node.name.startswith("SBSAR_Tx_") or _node.name.startswith("SBSAR_Val_"):
                nodes.remove(_node)

    @staticmethod
    def update_images(graph, data):
        for _output in graph.outputs:
            if _output.type == "image":
                if _output.name in data["outputs"]:
                    _filepath = data["outputs"][_output.name]["path"]
                    _img_name = "{}_{}".format(graph.material.name, _output.name)
                    SUBSTANCE_MaterialManager.get_image(_img_name, _filepath)

    @staticmethod
    def init_outputs(nodes, items, shader_prefs, shader_graph, addons_prefs, data, graph, new_nodes=None):
        _location = [-700, 0]
        for _output in graph.outputs:
            if _output.name not in data["outputs"]:
                continue
            if not data["outputs"][_output.name]["enabled"]:
                continue
            if _output.type == "image":
                if data["outputs"][_output.name]["path"] == "":
                    _output.filepath = ""
                    _output.filename = ""
                    continue

                _filepath = data["outputs"][_output.name]["path"]
                _filename = bpy.path.basename(data["outputs"][_output.name]["path"])
                _output.filepath = _filepath
                _output.filename = _filename

                _name = "SBSAR_Tx_{}".format(_output.name)
                _key = "sbsar_tx_{}".format(_output.name)
                if _output.name in shader_graph["outputs"]:
                    _type = shader_graph["outputs"][_output.name]["node_type"]
                else:
                    _type = shader_prefs["default_output"]["node_type"]

                items[_key] = nodes.new(_type)
                items[_key].name = _name

                # Set texture maps
                if shader_graph["rndr"] == Code_Renderer.cycles.value:
                    _img_name = "{}_{}".format(graph.material.name, _output.name)
                    _img = SUBSTANCE_MaterialManager.get_image(_img_name, _filepath)
                    items[_key].image = _img
                elif shader_graph["rndr"] == Code_Renderer.octane.value:
                    _img_name = "{}_{}".format(graph.material.name, _output.name)
                    _img = SUBSTANCE_MaterialManager.get_image(_img_name, _filepath)
                    items[_key].image = _img
                elif shader_graph["rndr"] == Code_Renderer.redshift.value:
                    _img_name = "{}_{}".format(graph.material.name, _output.name)
                    _img = SUBSTANCE_MaterialManager.get_image(_img_name, _filepath)
                    items[_key].inputs[0].default_value = False
                    items[_key].inputs["tex0"].default_value = _img
                elif shader_graph["rndr"] == Code_Renderer.renderman.value:
                    items[_key].filename = _filepath

                # Set colorspace
                if _output.name in shader_prefs["outputs"]:
                    if shader_graph["rndr"] == Code_Renderer.cycles.value:
                        _shader_output = shader_prefs["outputs"][_output.name]
                        _img.colorspace_settings.name = _shader_output["colorspace"]
                    elif shader_graph["rndr"] == Code_Renderer.octane.value:
                        _shader_output = shader_prefs["outputs"][_output.name]
                        _img.colorspace_settings.name = _shader_output["colorspace"]
                        items[_key].inputs[2].default_value = shader_graph["outputs"][_output.name]["gamma"]
                    elif shader_graph["rndr"] == Code_Renderer.redshift.value:
                        _shader_output = shader_prefs["outputs"][_output.name]
                        _img.colorspace_settings.name = _shader_output["colorspace"]
                        items[_key].inputs[4].default_value = shader_graph["outputs"][_output.name]["gamma"]
                    elif shader_graph["rndr"] == Code_Renderer.renderman.value:
                        _shader_output = shader_prefs["outputs"][_output.name]
                        items[_key].filename_colorspace = _shader_output["colorspace"]

                else:
                    if shader_graph["rndr"] == Code_Renderer.cycles.value:
                        _img.colorspace_settings.name = shader_prefs["default_output"]["colorspace"]
                    elif shader_graph["rndr"] == Code_Renderer.octane.value:
                        _img.colorspace_settings.name = shader_prefs["default_output"]["colorspace"]
                        items[_key].inputs[2].default_value = 1.0
                    elif shader_graph["rndr"] == Code_Renderer.redshift.value:
                        _img.colorspace_settings.name = shader_prefs["default_output"]["colorspace"]
                        items[_key].inputs[4].default_value = 1.0
                    elif shader_graph["rndr"] == Code_Renderer.renderman.value:
                        items[_key].filename_colorspace = _shader_output["colorspace"]

            else:
                _name = "SBSAR_Val_{}".format(_output.name)
                _key = "sbsar_val_{}".format(_output.name)

                # Get value
                _value = data["outputs"][_output.name]["value"]
                if _output.type == "integer2" or _output.type == "float2":
                    _value.append(0)
                    _value.append(0)
                elif _output.type == "integer3" or _output.type == "float3":
                    _value.append(0)

                # Init node
                if shader_graph["rndr"] == Code_Renderer.cycles.value:
                    if _output.type == "integer" or _output.type == "float":
                        items[_key] = nodes.new("ShaderNodeValue")
                        items[_key].outputs[0].default_value = _value
                        items[_key].name = _name
                    else:
                        items[_key] = nodes.new("ShaderNodeCombineXYZ")
                        items[_key].inputs[0].default_value = _value[0]
                        items[_key].inputs[1].default_value = _value[1]
                        items[_key].inputs[2].default_value = _value[2]
                        items[_key].name = _name
                elif shader_graph["rndr"] == Code_Renderer.octane.value:
                    if _output.type == "integer" or _output.type == "float":
                        items[_key] = nodes.new("OctaneGreyscaleColor")
                        items[_key].a_value = _value
                        items[_key].name = _name
                    else:
                        items[_key] = nodes.new("OctaneRGBColor")
                        items[_key].a_value = (_value[0], _value[1], _value[2])
                        items[_key].name = _name
                elif shader_graph["rndr"] == Code_Renderer.renderman.value:
                    items[_key] = nodes.new("PxrToFloat3PatternNode")
                    if _output.type == "integer" or _output.type == "float":
                        items[_key].input = _value
                        items[_key].name = _name
                    else:
                        items[_key].inputR = _value[0]
                        items[_key].inputG = _value[1]
                        items[_key].inputB = _value[2]
                        items[_key].name = _name

            if new_nodes is not None:
                new_nodes.append(_key)
            items[_key].location = (_location[0], _location[1])
            _location[1] -= 300

    @staticmethod
    def remove_unused_nodes(nodes, items, shader_graph):
        for _node in shader_graph["nodes"]:
            if "dependency" in _node:
                for _value in _node["dependency"]:
                    _value_tx = _value.replace("sbsar_", "sbsar_tx_")
                    _value_val = _value.replace("sbsar_", "sbsar_val_")
                    if _value_tx not in items and _value_val not in items:
                        nodes.remove(items[_node["id"]])
                        del items[_node["id"]]
                        break

    @staticmethod
    def init_properties(items, shader_graph, shader_prefs, graph, data, context):
        for _property in shader_graph["properties"]:
            if _property["id"] == "sbsar_tx_":
                for _key in items:
                    if _key.startswith("sbsar_tx_"):
                        SUBSTANCE_MaterialManager.set_property(
                            _property,
                            items[_key],
                            shader_prefs,
                            shader_graph,
                            graph,
                            data,
                            context
                            )
            else:
                if _property["id"] not in items:
                    continue
                SUBSTANCE_MaterialManager.set_property(
                    _property,
                    items[_property["id"]],
                    shader_prefs,
                    shader_graph,
                    graph,
                    data,
                    context
                    )

    @staticmethod
    def set_property(prop, node, shader_prefs, shader_graph, graph, data, context):
        if "input" in prop:
            _item = node.inputs[prop["input"]]
        else:
            _item = node

        if prop["type"] == "bool":
            _value = prop["value"]
        elif prop["type"] == "string":
            _value = prop["value"]
        elif prop["type"] == "float":
            _value = prop["value"]
        elif prop["type"] == "tiling":
            _value = graph.tiling.get()
            _value = SUBSTANCE_Utils.fix_tiling_value(_value, shader_graph["rndr"])
        elif prop["type"] == "physical_size":
            _value = graph.physical_size.get()
            _value = SUBSTANCE_Utils.get_physical_size(_value, context)
            _value = [1/_value[0], 1/_value[1], 1/_value[0]]
        elif prop["type"] == "ao_mix":
            _value = getattr(shader_prefs["inputs"], prop["type"])
        elif prop["type"] == "disp_minlevel":
            _value = getattr(shader_prefs["inputs"], prop["type"])
        elif prop["type"] == "disp_maxlevel":
            _value = getattr(shader_prefs["inputs"], prop["type"])
        elif prop["type"] == "disp_midlevel":
            _value = getattr(shader_prefs["inputs"], prop["type"])
        elif prop["type"] == "disp_scale":
            _value = getattr(shader_prefs["inputs"], prop["type"])
        elif prop["type"] == "disp_physical_scale":
            _value = graph.physical_size.get()[2]
        elif prop["type"] == "projection_blend":
            _value = getattr(shader_prefs["inputs"], prop["type"])
        elif prop["type"] == "emissive_intensity":
            if "emissive" in data["outputs"]:
                _value = getattr(shader_prefs["inputs"], prop["type"])
            else:
                _value = 0.0
            if shader_graph["rndr"] == Code_Renderer.cycles.value:
                _item = node.inputs["Emission Strength"]
            elif shader_graph["rndr"] == Code_Renderer.octane.value:
                pass

        else:
            _value = prop["value"]
        setattr(_item, prop["name"], _value)

    @staticmethod
    def add_frames(nodes, items, shader_graph):
        for _node in shader_graph["nodes"]:
            if _node["type"] != "NodeFrame":
                continue

            if _node["id"] == "sbsar_frame":
                for _key in items:
                    if _key != "sbsar_frame" and _key.startswith("sbsar_"):
                        items[_key].parent = items[_node["id"]]
            else:
                for _key in _node["children"]:
                    if _key in items:
                        items[_key].parent = items[_node["id"]]
            items[_node["id"]].update()

    @staticmethod
    def group_nodes(material, context, items):
        _temp_override = get_shader_editor_context()
        _old_material = bpy.context.object.active_material
        with context.temp_override(**_temp_override):
            context.object.active_material = material
            _temp_override['space'].node_tree = material.node_tree
            for _key, _item in items.items():
                if _key.startswith("sbsar_"):
                    _item.select = True
                else:
                    _item.select = False
            bpy.ops.node.group_make()
            for _key, _item in items.items():
                print(_item.name, _item.type)

            context.object.active_material = _old_material
            _temp_override['space'].node_tree = _old_material.node_tree

    @staticmethod
    def init_links(material, items, shader_graph):
        for _link in shader_graph["links"]:
            # Emission backward compatibility
            if bpy.app.version >= (4, 0, 0):
                pass
            else:
                if _link["input"] == "Emission Color":
                    _link["input"] = "Emission"

            if _link["from"] == "sbsar_tx_" or _link["to"] == "sbsar_tx_":
                if _link["from"] != "sbsar_tx_" and _link["from"] not in items:
                    continue
                if _link["to"] != "sbsar_tx_" and _link["to"] not in items:
                    continue

                for _item in items:
                    if not _item.startswith("sbsar_tx_"):
                        continue
                    _from = _link["from"]
                    _to = _link["to"]
                    if _link["from"] == "sbsar_tx_":
                        _from = _item
                    if _link["to"] == "sbsar_tx_":
                        _to = _item
                    if _link["output"] not in items[_from].outputs:
                        continue
                    if _link["input"] not in items[_to].inputs:
                        continue

                    material.node_tree.links.new(
                        items[_from].outputs[_link["output"]],
                        items[_to].inputs[_link["input"]])
            else:
                _from_tx = _link["from"].replace("sbsar_", "sbsar_tx_")
                _to_tx = _link["to"].replace("sbsar_", "sbsar_tx_")

                _from_val = _link["from"].replace("sbsar_", "sbsar_val_")
                _to_val = _link["to"].replace("sbsar_", "sbsar_val_")

                _from = ""
                _to = ""
                if _from_tx in items:
                    _from = _from_tx
                elif _from_val in items:
                    _from = _from_val
                else:
                    continue

                if _to_tx in items:
                    _to = _to_tx
                elif _to_val in items:
                    _to = _to_val
                else:
                    continue

                _output = _link["output"]
                if _link["output"] in items[_from].outputs:
                    _output == _link["output"]
                elif "Value" in items[_from].outputs:
                    _output = "Value"
                elif "Vector" in items[_from].outputs:
                    _output = "Vector"
                else:
                    continue

                if _link["input"] not in items[_to].inputs:
                    continue

                material.node_tree.links.new(
                    items[_from].outputs[_output],
                    items[_to].inputs[_link["input"]])

    @staticmethod
    def cycles_update(items):
        for _key in items:
            if not hasattr(items[_key], "image"):
                continue

            _img = items[_key].image
            items[_key].image = None
            SUBSTANCE_Threads.timer_thread_run(
                RENDER_IMG_UPDATE_DELAY_S,
                SUBSTANCE_MaterialManager.reset_image,
                (items[_key], _img))

    @staticmethod
    def rndr_error(message):
        SUBSTANCE_Utils.log_data(
            "ERROR",
            message,
            display=True)
        SUBSTANCE_Threads.cursor_pop()

    @staticmethod
    def create_shader_network(context, sbsar, graph, data):
        try:
            # Time
            SUBSTANCE_Threads.cursor_push('WAIT')
            _time_start = time.time()

            _addons_prefs, _shader_idx, _shader = SUBSTANCE_Utils.get_selected_shader(context, int(graph.shaders_list))
            _shader_file = SUBSTANCE_Utils.get_shader_file(_shader.filename)
            _shader_graph = SUBSTANCE_Utils.get_json(_shader_file)
            _shader_prefs = SUBSTANCE_Utils.get_shader_prefs(context, _shader)

            _rndr = SUBSTANCE_Utils.get_renderer(context=bpy.context)
            if _shader_graph["rndr"] != _rndr:
                _out_message = "Shader [{}] is not available for current renderer [{}]".format(
                        _shader_graph["label"],
                        context.scene.render.engine)
                SUBSTANCE_MaterialManager.rndr_error(_out_message)
                return

            _material = SUBSTANCE_MaterialManager.get_existing_material(graph.material.name)
            if _material is None or _shader.name != graph.material.shader:
                # Initialize material
                if _material is None:
                    _out_message_type = "INFO"
                    _out_message = "Material [{}] created in [{}]seconds"
                    _material = bpy.data.materials.new(name=graph.material.name)
                    _material.use_nodes = True
                    if _addons_prefs.auto_apply_material:
                        SUBSTANCE_MaterialManager.auto_apply_material(context, data, _material)
                else:
                    _out_message_type = "INFO"
                    _out_message = "Shader Preset [{}] changed in [{}]seconds"
                _nodes = _material.node_tree.nodes
                SUBSTANCE_MaterialManager.empty_material(_material, _nodes, graph)

                _items = SUBSTANCE_MaterialManager.init_base_nodes(_nodes, graph, _shader_graph)

                # Initialize Enabled outputs
                SUBSTANCE_MaterialManager.init_outputs(
                    _nodes,
                    _items,
                    _shader_prefs,
                    _shader_graph,
                    _addons_prefs,
                    data,
                    graph)

                # Remove unused Nodes
                SUBSTANCE_MaterialManager.remove_unused_nodes(_nodes, _items, _shader_graph)

                # Initialize shader properties
                SUBSTANCE_MaterialManager.init_properties(
                    _items,
                    _shader_graph,
                    _shader_prefs,
                    graph,
                    data,
                    context)

                # Add Frames
                SUBSTANCE_MaterialManager.add_frames(_nodes, _items, _shader_graph)

                # Initialize links
                SUBSTANCE_MaterialManager.init_links(_material, _items, _shader_graph)

                graph.material.shader = _shader.name
                _material.use_fake_user = _addons_prefs.auto_fake_usr

                # Create group
                # SUBSTANCE_MaterialManager.group_nodes(_material, context, _items)

            else:
                _nodes = _material.node_tree.nodes
                # Reload image files and update file format
                SUBSTANCE_MaterialManager.update_images(graph, data)

                if graph.update_tx_only:
                    _out_message_type = "INFO"
                    _out_message = "Textures [{}] updated in [{}]seconds"

                    # Add all SBSAR texture nodes
                    _items = {}
                    for _node in _nodes:
                        if _node.name.startswith("SBSAR_Tx_"):
                            _output = _node.name.replace("SBSAR_Tx_", "")
                            _items[_output] = _node

                else:
                    _out_message_type = "INFO"
                    _out_message = "Material [{}] updated in [{}]seconds"

                    _items = SUBSTANCE_MaterialManager.init_base_nodes(_nodes, graph, _shader_graph)
                    SUBSTANCE_MaterialManager.clean_sbsar_nodes(_nodes)

                    # Initialize Enabled outputs
                    SUBSTANCE_MaterialManager.init_outputs(
                        _nodes,
                        _items,
                        _shader_prefs,
                        _shader_graph,
                        _addons_prefs,
                        data,
                        graph)

                    # Remove unused Nodes
                    SUBSTANCE_MaterialManager.remove_unused_nodes(_nodes, _items, _shader_graph)

                    # Initialize shader properties
                    SUBSTANCE_MaterialManager.init_properties(
                        _items,
                        _shader_graph,
                        _shader_prefs,
                        graph,
                        data,
                        context)

                    # Add Frames
                    SUBSTANCE_MaterialManager.add_frames(_nodes, _items, _shader_graph)

                    # Initialize links
                    SUBSTANCE_MaterialManager.init_links(_material, _items, _shader_graph)

                # Hack to autoupdate images in cycles
                if _addons_prefs.cycles_autoupdate_enabled:
                    SUBSTANCE_MaterialManager.cycles_update(_items)

        except Exception:
            _out_message_type = "ERROR"
            _out_message = "An error ocurred while setting the material [{}]. [{}]seconds"
            SUBSTANCE_Utils.log_data("ERROR", "Exception - Susbtance material creation error")
            SUBSTANCE_Utils.log_traceback(traceback.format_exc())

        # Time
        _time_end = time.time()
        _load_time = round(_time_end - _time_start, 3)
        SUBSTANCE_Utils.log_data(
                _out_message_type,
                _out_message.format(graph.material.name, _load_time),
                display=True)

        # UPDATE UI
        SUBSTANCE_Utils.toggle_redraw(context)
        SUBSTANCE_Threads.cursor_pop()
