# Copyright Tobias Stelzer 2020

# ##### BEGIN GPL LICENSE BLOCK #####
#    This file is part of MeshAnalyzerPro.
#
#    MeshAnalyzerPro is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MeshAnalyzerPro is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MeshAnalyzerPro.  If not, see <https://www.gnu.org/licenses/>.

import bpy
import gpu
from mathutils import Vector
from gpu_extras.batch import batch_for_shader
from .Analyze_Poles import *

class DrawClass:

    def __init__(self):
        args = (self)
        self.draw_handle = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_callback,(), 'WINDOW', "POST_VIEW"
        )
        self.shader = gpu.shader.from_builtin('UNIFORM_COLOR')

    def draw_callback(self):
        context = bpy.context
        key = __package__
        prefs = bpy.context.preferences.addons[key].preferences
        if bpy.context.mode == 'EDIT_MESH':
            if bpy.context.object.show_all == False:
                return
            if DrawClass.hasMeshChanged(context):
                bpy.context.active_object.Recalc = True
                return
            gpu.state.blend_set('ALPHA')
            if prefs.show_poles:
                for indexList in bpy.context.active_object.ListOfPolesLists:
                    DrawClass.draw_poles(self, indexList, prefs)
            if prefs.show_doubles:
                for indexList in bpy.context.active_object.ListOfDoubleIndices:
                    DrawClass.draw_doubles(self, indexList, prefs)
            if prefs.show_singleedges:
                for indexList in bpy.context.active_object.ListOfSingleEdgeVertices:
                    DrawClass.draw_edges(self, indexList, prefs)
            if prefs.show_nonmanifolds:
                for indexList in bpy.context.active_object.ListOfNonManifoldEdgeVertices:
                    DrawClass.draw_edges(self, indexList, prefs)
            if prefs.show_polygons:
                for indexList in bpy.context.active_object.ListOfnGnonVertices:
                    DrawClass.draw_polygons(self, indexList, prefs)
            gpu.state.blend_set('NONE')
            
    def remove_draw_handler(self):
            if self.draw_handle is not None and "RNA_HANDLE_REMOVED" not in  str(self.draw_handle):
                bpy.types.SpaceView3D.draw_handler_remove(self.draw_handle, 'WINDOW')
                self.draw_handle = None
        
    def hasMeshChanged(context):
        if len(context.active_object.data.vertices) != context.active_object.numberOfVertices:
            return True
        if len(context.active_object.data.edges) != context.active_object.numberOfEdges:
            return True
        if len(context.active_object.data.polygons) != context.active_object.numberOfFaces:
            return True
        return False

    def draw_poles(self,indexList, prefs):
        edgeCount = indexList.edgeCount
        if len(indexList.indexList) == 0:
            return
        # if bpy.context.object.ListOfPoles[indexList.name].show == False:
        #     return
        if (edgeCount <= 2):
            if not prefs.show_2_poles:
                return
            color = prefs.pole_2_color
        if (edgeCount == 3):
            if not prefs.show_3_poles:
                return
            color = prefs.pole_3_color
        if (edgeCount == 4):
            if not prefs.show_4_poles:
                return
            color = prefs.pole_4_color
        if (edgeCount == 5):
            if not prefs.show_5_poles:
                return
            color = prefs.pole_5_color
        if (edgeCount >= 6):
            if not prefs.show_6_poles:
                return
            color = prefs.pole_6_color

        if not prefs.x_ray:
            gpu.state.depth_test_set('LESS_EQUAL')
        else:
            gpu.state.depth_test_set('NONE')
        gpu.state.point_size_set(prefs.point_size)

        bpy.context.object.update_from_editmode()
        obj = bpy.context.active_object
        data = obj.data

        coords = []
        for vert in indexList.indexList:
            if(vert.index >= len(bpy.context.active_object.data.vertices)):
                bpy.context.active_object.Recalc = True
                return
            if not data.vertices[vert.index].hide:
                coords.append(obj.matrix_world @ data.vertices[vert.index].co)
        batch = batch_for_shader(self.shader, 'POINTS', {"pos": coords})
        self.shader.bind()
        self.shader.uniform_float("color",color)
        batch.draw(self.shader)

    def draw_doubles(self, indexList, prefs):
        if len(indexList.indexList) == 0:
            return
        if not prefs.x_ray:
            gpu.state.depth_test_set('LESS_EQUAL')
        else:
            gpu.state.depth_test_set('NONE')
        gpu.state.point_size_set(prefs.point_size)

        bpy.context.object.update_from_editmode()
        obj = bpy.context.active_object
        data = obj.data

        coords = []
        for vert in indexList.indexList:
            if(vert.index >= len(bpy.context.active_object.data.vertices)):
                bpy.context.active_object.Recalc = True
                return
            if not data.vertices[vert.index].hide:
                coords.append(obj.matrix_world @ data.vertices[vert.index].co)
        batch = batch_for_shader(self.shader, 'POINTS', {"pos": coords})
        self.shader.bind()
        self.shader.uniform_float("color",prefs.double_color)
        batch.draw(self.shader)

    def draw_edges(self, indexList, prefs):
        if len(indexList.indexList) == 0:
            return
        if indexList.name == "single_edge_vertices":
            color = prefs.singleedge_color
        if indexList.name == "non_manifold_edge_vertices":
            color = prefs.nonmanifold_color

        if not prefs.x_ray:
            gpu.state.depth_test_set('LESS_EQUAL')
        else:
            gpu.state.depth_test_set('NONE')
        gpu.state.point_size_set(prefs.point_size)
        gpu.state.line_width_set(prefs.edge_width)

        bpy.context.object.update_from_editmode()
        obj = bpy.context.active_object
        data = obj.data

        coords = []

        for vert in indexList.indexList:
            if(vert.index1 >= len(bpy.context.active_object.data.vertices) 
            or vert.index2 >= len(bpy.context.active_object.data.vertices)):
                bpy.context.active_object.Recalc = True
                return
            if not (data.vertices[vert.index1].hide or data.vertices[vert.index2].hide):
                coords.append(obj.matrix_world @ data.vertices[vert.index1].co)
                coords.append(obj.matrix_world @ data.vertices[vert.index2].co)

        batch = batch_for_shader(self.shader, 'LINES', {"pos": coords})
        self.shader.bind()
        self.shader.uniform_float("color",color)
        batch.draw(self.shader)

    def draw_polygons(self, indexList, prefs):
        if len(indexList.indexList) == 0:
            return
        # if bpy.context.object.ListOfPolygons[indexList.name].show == False:
        #     return
        if indexList.count == 3:
            if not prefs.show_tris:
                return
            color = prefs.tri_color
        else:
            if indexList.count == 4:
                if not prefs.show_quads:
                    return
                color = prefs.quad_color
            else:
                if not prefs.show_ngons:
                    return
                color = prefs.nGon_color

        if not prefs.x_ray:
            gpu.state.depth_test_set('LESS_EQUAL')
        else:
            gpu.state.depth_test_set('NONE')
            
        bpy.context.object.update_from_editmode()
        obj = bpy.context.active_object
        data = obj.data

        coords = []

        for triangle in indexList.indexList:
            if(triangle.index1 >= len(bpy.context.active_object.data.vertices) 
            or triangle.index2 >= len(bpy.context.active_object.data.vertices) or
            triangle.index3 >= len(bpy.context.active_object.data.vertices)):
                bpy.context.active_object.Recalc = True
                return  
            if not (data.vertices[triangle.index1].hide or data.vertices[triangle.index2].hide or data.vertices[triangle.index3].hide):
                normal = Vector(triangle.offset) * prefs.offset
                coords.append(obj.matrix_world @ (data.vertices[triangle.index1].co + normal))
                coords.append(obj.matrix_world @ (data.vertices[triangle.index2].co + normal))
                coords.append(obj.matrix_world @ (data.vertices[triangle.index3].co + normal))

        batch = batch_for_shader(self.shader, 'TRIS', {"pos": coords})
        self.shader.bind()
        self.shader.uniform_float("color",color)
        batch.draw(self.shader)
        return