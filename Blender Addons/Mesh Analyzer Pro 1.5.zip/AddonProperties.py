# Copyright Tobias Stelzer 2020

# ##### BEGIN GPL LICENSE BLOCK #####
#    This file is part of MeshAnalyzerPro.
#
#    MeshAnalyzerPro is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MeshAnalyzerPro is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MeshAnalyzerPro.  If not, see <https://www.gnu.org/licenses/>.

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatVectorProperty, FloatProperty
from . import UI

#--- ### Add-On Preferences
#default values for the keymap items.new() call (see register_keymap() method)
hotkey_defaults = {"idname": 'wm.call_menu_pie', "type": 'M', "value": 'PRESS', "shift": True, "ctrl": False, "alt": False}

class MeshAnalyzerPreferences(bpy.types.AddonPreferences):
    '''This class provides the user the possibility of altering the keyboard shortcut
    assigned to the Boolean pie menu
    '''
    bl_idname = __package__
    
    def on_update(self, context):
        unregister_keymap()
        register_keymap()
    
    shift : BoolProperty(name = "Shift", description = "Use the [Shift] key", default = hotkey_defaults["shift"], update=on_update)
    ctrl : BoolProperty(name = "Ctrl", description = "Use the [CTRL] key", default = hotkey_defaults["ctrl"], update=on_update)
    alt : BoolProperty(name = "Alt", description = "Use the [Alt] key", default = hotkey_defaults["alt"], update=on_update)
    key : EnumProperty(items = [('None',"None","No hotkey")] + [tuple([chr(i),chr(i),"[%s] key" % chr(i)]) for i in range(65,95)],
        name = "Keyboard key", 
        description = "Selected keyboard key", 
        default = hotkey_defaults["type"], update=on_update)

    default_on : BoolProperty(
        name="Overlay Default on",
        description="Is overlay on or off per Default",
        default=False
        )

    show_poles : BoolProperty(
        name="Show Poles",
        description="Draw poles on 3D View",
        default=True
        )

    show_2_poles : BoolProperty(
        name="Show 2(-)-Poles",
        description="Draw poles with 2 or lesser edges on 3D View",
        default=True
        )

    show_3_poles : BoolProperty(
        name="Show 3-Poles",
        description="Draw poles with 3 edges on 3D View",
        default=True
        )

    show_4_poles : BoolProperty(
        name="Show 4-Poles",
        description="Draw poles with 4 edges on 3D View",
        default=False
        )

    show_5_poles : BoolProperty(
        name="Show 5-Poles",
        description="Draw poles with 5 edges on 3D View",
        default=True
        )

    show_6_poles : BoolProperty(
        name="Show 6(+)-Poles",
        description="Draw poles with 6 or more edges on 3D View",
        default=True
        )

    pole_2_color : FloatVectorProperty(
            name="2(-)-Pole Color",
            description="Custom color for poles with 2 or lesser edges",
            min=0.0, max=1.0,
            default=(1, 0, 0.8, 0.5),
            size=4,
            subtype='COLOR'
            )

    pole_3_color : FloatVectorProperty(
            name="3-Pole Color",
            description="Custom color for poles with 3 edges",
            min=0.0, max=1.0,
            default=(1, 0, 0, 0.5),
            size=4,
            subtype='COLOR'
            )

    pole_4_color : FloatVectorProperty(
        name="4-Pole Color",
        description="Custom color for poles with 4 edges",
        min=0.0, max=1.0,
        default=(0, 1, 0, 0.5),
        size=4,
        subtype='COLOR'
        )

    pole_5_color : FloatVectorProperty(
            name="5-Pole Color",
            description="Custom color for poles with 5 edges",
            min=0.0, max=1.0,
            default=(0, 0, 1, 0.5),
            size=4,
            subtype='COLOR'
            )

    pole_6_color : FloatVectorProperty(
            name="6(+)-Pole Color",
            description="Custom color for poles with 6 or more edges",
            min=0.0, max=1.0,
            default=(0, 1, 1, 0.5),
            size=4,
            subtype='COLOR'
            )

    point_size : FloatProperty(
            name = "Point Size",
            description="Size of the vertex overlay",
            min = 0.0, max=30.0,
            default=7.5
    )

    double_color : FloatVectorProperty(
        name="Standard Double Color",
        description="Custom color for poles with 6 or more edges",
        min=0.0, max=1.0,
        default=(1, 1, 1, 0.5),
        size=4,
        subtype='COLOR'
        )

    show_doubles : BoolProperty(
        name="Show doubles",
        description="Draw doubles on 3D View",
        default=True
        )

    x_ray : BoolProperty(
            name = "X-Ray",
            description="Enable X-Ray for overlay",
            default=False
    )

    auto_sync : BoolProperty(
        name = "Auto-Sync",
        description="Sync Display in Edit Mode. Might impact performance.",
        default=True
    )

    show_singleedges : BoolProperty(
        name="Show single edges",
        description="Draws single edges on 3D View",
        default=True
        )

    singleedge_color : FloatVectorProperty(
        name="Single Edge Color",
        description="Custom color for single Edges",
        min=0.0, max=1.0,
        default=(0.8, 0.8, 0, 0.5),
        size=4,
        subtype='COLOR'
        )

    show_nonmanifolds : BoolProperty(
        name="Show non-manifold edges",
        description="Draws non-manifold edges on 3D View",
        default=True
        )

    nonmanifold_color : FloatVectorProperty(
        name="Non-manifold Edge Color",
        description="Custom color for non-manifold Edges",
        min=0.0, max=1.0,
        default=(0.8, 0.2, 0, 0.5),
        size=4,
        subtype='COLOR'
        )

    edge_width : FloatProperty(
            name = "Edge Width",
            description="Width of the edge overlay",
            min = 0.0, max=30.0,
            default=5
    )

    show_polygons : BoolProperty(
        name="Show polygons",
        description="Draws polygons on 3D View",
        default=True
        )

    offset : FloatProperty(
        name = "Face Offset",
        description="Face offset for drawing polygons.",
        min=0.000,
        default=0.01
    )

    show_tris : BoolProperty(
        name="Show triangles",
        description="Draw triangles on 3D View",
        default=True
        )

    show_quads : BoolProperty(
        name="Show Quads",
        description="Draw quads on 3D View",
        default=False
        )

    show_ngons : BoolProperty(
        name="Show nGons",
        description="Draw nGons on 3D View",
        default=True
        )

    tri_color : FloatVectorProperty(
        name="Triangle Color",
        description="Custom color for tris",
        min=0.0, max=1.0,
        default=(0, 0, 1, 0.2),
        size=4,
        subtype='COLOR'
        )

    quad_color : FloatVectorProperty(
        name="Quad Color",
        description="Custom color for quads",
        min=0.0, max=1.0,
        default=(0, 1, 0, 0.2),
        size=4,
        subtype='COLOR'
        )

    nGon_color : FloatVectorProperty(
        name="nGon Color",
        description="Custom color for nGons",
        min=0.0, max=1.0,
        default=(1, 0, 0, 0.2),
        size=4,
        subtype='COLOR'
        )
    
    def draw(self, context):
        layout = self.layout 
        box = layout.box()
        box.label(text = "Shortcut:")
        row = box.row(align=True)
        row.alignment = 'LEFT'
        row.separator(factor = 10)
        row.prop(self,"key",text="Keyboard shortcut")
        row.separator(factor = 3)
        row.label(text = "with:")
        row.prop(self,"shift")
        row.prop(self,"ctrl")
        row.prop(self,"alt")

        box = layout.box()
        box.label(text = "General Options")
        box.prop(self,'default_on')
        box.label(text="(Restart Blender for Default On to take effect)")
        box.prop(self,'x_ray')
        box.prop(self,'auto_sync')

        box = layout.box()
        box.label(text = "Vertex Options")
        box.prop(self,'show_poles')
        box.prop(self,'show_doubles')
        box.prop(self,'point_size')
        col_flow = box.column_flow(columns = 2, align=True)
        row = col_flow.row()
        row.prop(self,'double_color')
        row.prop(self,'show_doubles')

        row = col_flow.row()
        row.prop(self,'pole_2_color')
        row.prop(self,'show_2_poles')

        row = col_flow.row()
        row.prop(self,'pole_3_color')
        row.prop(self,'show_3_poles')

        row = col_flow.row()
        row.prop(self,'pole_4_color')
        row.prop(self,'show_4_poles')

        row = col_flow.row()
        row.prop(self,'pole_5_color')
        row.prop(self,'show_5_poles')

        row = col_flow.row()
        row.prop(self,'pole_6_color')
        row.prop(self,'show_6_poles')

        box = layout.box()
        box.label(text = "Edge Options")
        box.prop(self,'show_singleedges')
        box.prop(self,'show_nonmanifolds')
        box.prop(self,'edge_width')
        col_flow = box.column_flow(columns = 2, align=True)
        row = col_flow.row()
        row.prop(self,'singleedge_color')
        row.prop(self,'show_singleedges')

        row = col_flow.row()
        row.prop(self,'nonmanifold_color')
        row.prop(self,'show_nonmanifolds')

        box = layout.box()
        box.label(text = "Face Options")
        box.prop(self,'show_polygons')
        box.prop(self,'offset')
        col_flow = box.column_flow(columns = 2, align=True)

        row = col_flow.row()
        row.prop(self,'tri_color')
        row.prop(self,'show_tris')

        row = col_flow.row()
        row.prop(self,'quad_color')
        row.prop(self,'show_quads')

        row = col_flow.row()
        row.prop(self,'nGon_color')
        row.prop(self,'show_ngons')
                                           
#--- ### hotkey registration
addon_keymaps = [] #global list for this add-on keyboard shortcut definitions  

def register_keymap():
    '''Registers current hotkey'''
        
    args = hotkey_defaults
    
    if MeshAnalyzerPreferences.bl_idname in bpy.context.preferences.addons:
        #update args, according to preferences
        prf = bpy.context.preferences.addons[MeshAnalyzerPreferences.bl_idname].preferences
        
        args["type"] = prf.key #Use the user-defined key and its modifiers
        args["shift"], args["ctrl"], args["alt"] = prf.shift, prf.ctrl, prf.alt
    else:
        prf = None
    
    if args["type"] == 'None': return
        
    key_config = bpy.context.window_manager.keyconfigs.addon    
    if key_config:
        key_map = key_config.keymaps.new(name = "Mesh")
        hotkey = key_map.keymap_items.new(**args)
        hotkey.properties.name = UI.VIEW3D_MT_MeshAnalyzer.bl_idname
        addon_keymaps.append((key_map,hotkey))        
                            
def unregister_keymap():
    key_config = bpy.context.window_manager.keyconfigs.addon
    if key_config:
        for key_map, hotkey in addon_keymaps:
            key_map.keymap_items.remove(hotkey)
            addon_keymaps.clear()    