# Copyright Tobias Stelzer 2020

# ##### BEGIN GPL LICENSE BLOCK #####
#    This file is part of MeshAnalyzerPro.
#
#    MeshAnalyzerPro is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MeshAnalyzerPro is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MeshAnalyzerPro.  If not, see <https://www.gnu.org/licenses/>.

bl_info = {
    "name": "Mesh Analyzer",
    "author": "Tobias Stelzer",
    "version": (1, 5 ,0),
    "blender": (4, 2, 0),
    "location": "Mesh > Analyzer",
    "category": "Mesh",
    "description": "Analyze Meshes: Poles, doubles, single and nonmanifold edges, polygons. Including overlay and report function."
}

if "bpy" not in locals():
    from . import main
    from . import UI
    from . import Analyze_Poles
    from . import Select_Poles
    from . import Find_Doubles
    from . import Remove_Doubles
    from . import Find_Single_Edges
    from . import Find_Nonmanifolds
    from . import Select_Polygons
    from . import Analyze_Polygons 
    from . import Analyze_All
    from . import CreateReport
else:
    import importlib
    importlib.reload(main)
    importlib.reload(UI)
    importlib.reload(Analyze_Poles)
    importlib.reload(Select_Poles)
    importlib.reload(Find_Doubles)
    importlib.reload(Remove_Doubles)
    importlib.reload(Find_Single_Edges)
    importlib.reload(Find_Nonmanifolds)
    importlib.reload(Select_Polygons)
    importlib.reload(Analyze_Polygons)
    importlib.reload(Analyze_All)
    importlib.reload(CreateReport)

#from Analyze_Poles import MESH_OT_analyze
import bpy
from bpy.utils import register_class, unregister_class
#import bmesh
from bpy.props import IntProperty, StringProperty, BoolProperty, EnumProperty, CollectionProperty
#import string
#from builtins import object
from .CustomProperties import *
from .AddonProperties import * 
from .DrawClasses import DrawClass  
from bpy.app.handlers import persistent                         

classes = [
    Analyze_Poles.MESH_OT_analyze,
    Analyze_Polygons.MESH_OT_analyze_polygons,
    Select_Poles.MESH_OT_select_poles,
    Select_Polygons.MESH_OT_find_polygons,
    Select_Polygons.MESH_OT_select_polygons,
    Find_Doubles.MESH_OT_FindDoubles,
    Find_Doubles.MESH_OT_SelectDoubles,
    Remove_Doubles.MESH_OT_RemoveDoubles,
    Find_Single_Edges.MESH_OT_FindSingleEdges,
    Find_Single_Edges.MESH_OT_SelectSingleEdges,
    Find_Nonmanifolds.MESH_OT_FindNonManifoldEdges,
    Find_Nonmanifolds.MESH_OT_SelectNonManifoldEdges,
    Analyze_All.MESH_OT_analyze_all,
    CreateReport.MESH_OT_create_report,
    UI.MESH_UL_poleList,
    UI.MESH_UL_polygonList,
    UI.MESH_PT_AnalyzerPanel,
    UI.MESH_PT_VerticesAnalyzerPanel,
    UI.MESH_PT_EdgesAnalyzerPanel,
    UI.MESH_PT_PolygonAnalyzerPanel,
    UI.VIEW3D_MT_MeshAnalyzer,
    UI.AnalyzerSubMenu,
    MeshAnalyzerPreferences,
    MeshAnalyzerObjectInfos,
    VertexIndexProp,
    IndexListProp,
    EdgeVerticesIndexProp,
    EdgeIndexListProp,
    FaceVerticesIndexProp,
    FaceIndexListProp
    ]


def menu_draw(self, context):
    self.layout.operator_context = 'INVOKE_REGION_WIN'
    self.layout.menu(UI.AnalyzerSubMenu.bl_idname)

@persistent
def recalcHandler(self, scene):
    if bpy.context.active_object is not None:
        if bpy.context.active_object.Recalc and bpy.context.mode == 'EDIT_MESH' and bpy.context.preferences.addons[__package__].preferences.auto_sync:
            Analyze_Poles.analyze_poles(True)
            Find_Single_Edges.find_single_edges()
            Find_Doubles.find_doubles(0.0001)
            Find_Nonmanifolds.find_non_manifold_edges()
            Analyze_Polygons.analyze_ngons()
            if(bpy.context.active_object.DoubleCnt > 0):
                bpy.app.timers.register(double_timer, first_interval=10)

def double_timer():
    if bpy.context.active_object is not None:
        if bpy.context.active_object.get('Recalc') is not None:
            bpy.context.active_object.Recalc = True

drawClasses = {}

# Registering Add-On
def register():
    for cls in classes:
        register_class(cls)

    register_keymap()
    bpy.types.VIEW3D_MT_edit_mesh.append(menu_draw)

    bpy.types.Object.show_all = BoolProperty(name = "Show Everything", description= "Turn Overlays on and off for this object", default = bpy.context.preferences.addons[__package__].preferences.default_on)

    bpy.types.Object.ListOfPoles = bpy.props.CollectionProperty(type = MeshAnalyzerObjectInfos)
    bpy.types.Object.ListOfPoles_index = IntProperty(name = "Index for the list of Poles", default  = 0)
    bpy.types.Object.ListOfPolesLists = CollectionProperty(type= IndexListProp)

    bpy.types.Object.ListOfPolygons = bpy.props.CollectionProperty(type = MeshAnalyzerObjectInfos)
    bpy.types.Object.ListOfPolygons_index = IntProperty(name = "Index for the list of Polygons", default  = 0)
    bpy.types.Object.ListOfnGonsLists = CollectionProperty(type= IndexListProp)
    bpy.types.Object.ListOfnGnonVertices = CollectionProperty(type = FaceIndexListProp)

    bpy.types.Object.numberOfVertices = IntProperty(name = "Number of vertices in mesh", default = 0)
    bpy.types.Object.numberOfEdges = IntProperty(name = "Number of edges in mesh", default = 0)
    bpy.types.Object.numberOfFaces = IntProperty(name = "Number of vertices in mesh", default = 0)

    bpy.types.Object.DoubleCnt = bpy.props.IntProperty()
    bpy.types.Object.ListOfDoubleIndices = CollectionProperty(type = IndexListProp)

    bpy.types.Object.SingleEdgeCount = bpy.props.IntProperty()
    bpy.types.Object.ListOfSingleEdgeVertices = CollectionProperty(type = EdgeIndexListProp)
    bpy.types.Object.ListOfSingleEdgeIndices = CollectionProperty(type = IndexListProp)

    bpy.types.Object.NonManifoldEdges = bpy.props.IntProperty()
    bpy.types.Object.ListOfNonManifoldEdgeVertices = CollectionProperty(type = EdgeIndexListProp)
    bpy.types.Object.ListOfNonManifoldEdgeIndices = CollectionProperty(type = IndexListProp)

    bpy.types.Object.Recalc = bpy.props.BoolProperty(name = "Mesh needs recalc", default=False)

    drawClasses["Overlay"] = DrawClass()

    bpy.app.handlers.depsgraph_update_pre.append(recalcHandler)
    
def unregister():
    bpy.app.handlers.depsgraph_update_pre.remove(recalcHandler)

    for key, item in drawClasses.items():
        item.remove_draw_handler()

    del bpy.types.Object.ListOfPoles
    del bpy.types.Object.ListOfPoles_index
    del bpy.types.Object.ListOfPolygons
    del bpy.types.Object.ListOfPolygons_index
    del bpy.types.Object.ListOfnGonsLists
    del bpy.types.Object.ListOfnGnonVertices
    del bpy.types.Object.DoubleCnt
    del bpy.types.Object.SingleEdgeCount
    del bpy.types.Object.NonManifoldEdges 
    del bpy.types.Object.ListOfPolesLists
    del bpy.types.Object.ListOfSingleEdgeVertices
    del bpy.types.Object.ListOfSingleEdgeIndices
    del bpy.types.Object.ListOfNonManifoldEdgeVertices
    del bpy.types.Object.ListOfNonManifoldEdgeIndices
    del bpy.types.Object.numberOfVertices
    del bpy.types.Object.numberOfEdges
    del bpy.types.Object.numberOfFaces
    del bpy.types.Object.Recalc
    del bpy.types.Object.ListOfDoubleIndices
    del bpy.types.Object.show_all

    bpy.types.VIEW3D_MT_edit_mesh.remove(menu_draw)

    unregister_keymap()

    for cls in classes:
        unregister_class(cls) 