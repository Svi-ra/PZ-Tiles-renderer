# Copyright Tobias Stelzer 2020

# ##### BEGIN GPL LICENSE BLOCK #####
#    This file is part of MeshAnalyzerPro.
#
#    MeshAnalyzerPro is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MeshAnalyzerPro is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MeshAnalyzerPro.  If not, see <https://www.gnu.org/licenses/>.

from operator import index
import bpy
#import bmesh
from bpy.props import BoolProperty

from .Select_Poles import *
from .main import *

# Operator classes
class MESH_OT_analyze(bpy.types.Operator):
    '''Analyzes a mesh and selects poles'''
    bl_idname = "mesh.analyze"
    bl_label = "Analyze Poles"    
    bl_description = "Analyzes the mesh for poles"
    bl_options = {'REGISTER'}
    
    cnsdrBndr : BoolProperty(name = "Consider Boundary",
                              description = "Are vertices on the boundary considered?",
                              default = True)

    vertexGroupName = "-Pole"

    @classmethod
    def poll(cls,context):
        return(context.mode == 'EDIT_MESH')
    
    def execute(self, context):
        main(analyze_poles,[self.cnsdrBndr], cntx = context)
        return{'FINISHED'}
        
    def invoke(self,context,event):
        result = main(analyze_poles,[self.cnsdrBndr], cntx = context)
        if result[0] == SUCCESS:
            return {'FINISHED'}
        else:
            self.report(type = {result[0]}, message = result[1])
            return ('FINISHED' if result[0] == WARNING else 'CANCELLED')
            
def analyze_poles(considerBoundary):
    '''Analyzes the mesh for number of poles, creates vertex groups and selections.'''

    thisObject = bpy.context.active_object
    thisObject.ListOfPoles.clear()
    thisObject.ListOfPolesLists.clear()
    
    # Get the active mesh
    activeMesh = bpy.context.object.data
    
    # BMesh Representation
    bm = bmesh.from_edit_mesh(activeMesh)
    
    # Vertices
    bm.verts.ensure_lookup_table()
    vertices = bm.verts[:]

    poles = {}
       
    # Modify mesh here
    for vertex in vertices:
        if vertex.is_boundary and not considerBoundary:
            continue
        key = str(len(vertex.link_edges))
        if (poles.get(key) is None):
            poles[key] = [vertex.index]
        else:
            poles[key].append(vertex.index)
    

    for key in sorted(poles):
        value = poles[key]
        name = (key+"-Pole")
        if name in thisObject.ListOfPolesLists:
            list = thisObject.ListOfPolesLists[name]
            indexList = list.indexList
            indexList.clear()
            print(len(indexList))
        else:
            list = thisObject.ListOfPolesLists.add()
            list.name = name
            list.edgeCount = int(key)
            indexList = list.indexList
            indexList.clear()
        for item in value:
            vertIndex = indexList.add()
            vertIndex.index = item
        newListItem = thisObject.ListOfPoles.add()
        newListItem.name = name
        newListItem.poles = int(key)
        newListItem.count = len(value)
  
    bpy.context.active_object.numberOfVertices = len(activeMesh.vertices)
    bpy.context.active_object.numberOfEdges = len(activeMesh.edges)
    bpy.context.active_object.numberOfFaces = len(activeMesh.polygons)
    thisObject.Recalc = False