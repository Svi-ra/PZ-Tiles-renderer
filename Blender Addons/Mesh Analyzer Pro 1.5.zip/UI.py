# Copyright Tobias Stelzer 2020

# ##### BEGIN GPL LICENSE BLOCK #####
#    This file is part of MeshAnalyzerPro.
#
#    MeshAnalyzerPro is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MeshAnalyzerPro is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MeshAnalyzerPro.  If not, see <https://www.gnu.org/licenses/>.

import bpy

from .Analyze_Poles import MESH_OT_analyze
from .Select_Poles import MESH_OT_select_poles
from .Find_Doubles import MESH_OT_FindDoubles
from .Find_Doubles import MESH_OT_SelectDoubles
from .Remove_Doubles import MESH_OT_RemoveDoubles
from .Find_Single_Edges import MESH_OT_SelectSingleEdges
from .Find_Single_Edges import MESH_OT_FindSingleEdges
from .Find_Nonmanifolds import MESH_OT_FindNonManifoldEdges
from .Find_Nonmanifolds import MESH_OT_SelectNonManifoldEdges
from .Select_Polygons import MESH_OT_select_polygons
from .Analyze_Polygons import MESH_OT_analyze_polygons
from .Analyze_All import MESH_OT_analyze_all
from .CreateReport import MESH_OT_create_report


# Icon Definitions:
analyze_poles_icon =  "OBJECT_ORIGIN"
select_poles_icon = "STICKY_UVS_LOC"
find_doubles_icon = "PIVOT_INDIVIDUAL"
remove_doubles_icon = "PIVOT_MEDIAN"
find_single_edges_icon = "NORMALS_VERTEX"
find_nonmanifolds_icon = "ORIENTATION_GLOBAL"
analyze_polygons_icon = "SNAP_VOLUME"
select_polyogns_icon = "SELECT_INTERSECT"
analyze_all_icon = "PLAY"
create_report_icon = "TEXT"

class AnalyzerUIPanel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Mesh Analyzer Pro'
    bl_context = "mesh_edit"
    
    @classmethod
    def poll(cls, context):
        return (context.object is not None)
        
# Panel class
class MESH_PT_AnalyzerPanel(AnalyzerUIPanel, bpy.types.Panel):   
    '''Creates the panel to control the mesh analyzer'''
    bl_idname = 'MESH_PT_AnalyzerPanel'   
    bl_label = "MeshAnalyzerPro"
    #bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):     
        layout = self.layout
        
        layout.operator(MESH_OT_analyze_all.bl_idname, icon=analyze_all_icon)
        layout.operator(MESH_OT_create_report.bl_idname, icon=create_report_icon)
        layout.prop(bpy.context.object,"show_all",text = "Toggle Overlay")
        layout.label(text = "Open the subpanels")
        #layout.label(text = "start analyzing your mesh.")
    
class MESH_PT_VerticesAnalyzerPanel(AnalyzerUIPanel, bpy.types.Panel):
    bl_idname = 'MESH_PT_VerticesAnalyzerPanel'   
    bl_label = "MeshAnalyzer - Vertices:"
    bl_parent_id = "MESH_PT_AnalyzerPanel"
    bl_options = {'DEFAULT_CLOSED'} 
        
        
    def draw(self, context):     
        layout = self.layout    

        layout.label(text="Poles:")
        layout.operator(MESH_OT_analyze.bl_idname, icon = analyze_poles_icon)
    
        # List of pole type, number of vertices and vertex group toggle
        split = layout.split(factor = 0.7)
        
        # first column
        col = split.column()
        col.label(text = 'Select')
                    
        # second column
        col = split.column()
        col.label(text = 'Vertex Count')

        # col = split.column()
        # col.label(text = 'Show Pole')
        
        layout.template_list("MESH_UL_poleList", "PoleList", context.object, "ListOfPoles", context.object,"ListOfPoles_index")

        layout.label(text = 'Doubles:')
        
        split = layout.split(factor = 0.5)
        
        col = split.column()
        col.operator(MESH_OT_FindDoubles.bl_idname, icon = find_doubles_icon)
        col = split.column()
        col.operator(MESH_OT_SelectDoubles.bl_idname, icon = find_doubles_icon)
        
        
        box = layout.box()
        split = box.split(factor = 0.7)

        col = split.column()
        col.label (text = 'Doubles')
        col = split.column()
        col.label(text = str(bpy.context.object.DoubleCnt))
        
        layout.operator(MESH_OT_RemoveDoubles.bl_idname, icon = remove_doubles_icon)
               
        

class MESH_PT_EdgesAnalyzerPanel(AnalyzerUIPanel, bpy.types.Panel):
    bl_idname = 'MESH_PT_EdgesAnalyzerPanel'   
    bl_label = "MeshAnalyzer - Edges"
    bl_parent_id = "MESH_PT_AnalyzerPanel"
    bl_options = {'DEFAULT_CLOSED'} 
    
    def draw(self, context):     
        layout = self.layout

        layout.label(text = "Edges")
        split = layout.split(factor = 0.5)
        col = split.column()
        col.operator(MESH_OT_FindSingleEdges.bl_idname, icon = find_single_edges_icon)
        col = split.column()
        col.operator(MESH_OT_SelectSingleEdges.bl_idname, icon = find_single_edges_icon)
        
        split = layout.split(factor = 0.7)
        col = split.column()
        col.label(text = "")        
        col = split.column()
        col.label(text = "Count")
        
        box = layout.box()
        split = box.split(factor = 0.7)
        
        col = split.column()
        col.label(text = 'Single Edges')
        
        col = split.column()
        col.label(text = str(bpy.context.object.SingleEdgeCount))
        
        split = layout.split(factor = 0.5)
        col = split.column()
        col.operator(MESH_OT_FindNonManifoldEdges.bl_idname, icon = find_nonmanifolds_icon)
        col = split.column()
        col.operator(MESH_OT_SelectNonManifoldEdges.bl_idname, icon = find_nonmanifolds_icon)
        
        split = layout.split(factor = 0.7)
        col = split.column()
        col.label(text = "")        
        col = split.column()
        col.label(text = "Count")
        
        box = layout.box()
        split = box.split(factor = 0.7)
        
        col = split.column()
        col.label(text = 'Non-Manifold Edges')
        col = split.column()
        col.label(text = str(bpy.context.object.NonManifoldEdges))

class MESH_PT_PolygonAnalyzerPanel(AnalyzerUIPanel, bpy.types.Panel):
    bl_idname = 'MESH_PT_PolygonAnalyzerPanel'   
    bl_label = "MeshAnalyzer - Polygons"
    bl_parent_id = "MESH_PT_AnalyzerPanel"
    bl_options = {'DEFAULT_CLOSED'} 
        
        
    def draw(self, context):     
        layout = self.layout

        layout.label(text = 'Faces')
        
        layout.operator(MESH_OT_analyze_polygons.bl_idname, icon = analyze_polygons_icon)
        
        # List of p type, number of edges
        split = layout.split(factor=0.7)
        
        # first column
        col = split.column()
        col.label(text = 'Select')
                    
        # second column
        col = split.column()
        col.label(text = 'Count')

        # second column
        # col = split.column()
        # col.label(text = 'Show')
        
        layout.template_list("MESH_UL_polygonList", "PolygonList", context.object, "ListOfPolygons", context.object,"ListOfPolygons_index")
    
class MESH_UL_poleList(bpy.types.UIList):

    # Called for each drawn item.
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index, flt_flag):
        # 'DEFAULT' and 'COMPACT' layout types should usually use the same draw code.
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            split = layout.split(factor = 0.7, align = True)
            row = split.column()
            row.operator(MESH_OT_select_poles.bl_idname, text = ("Select " + str(item.poles) + "-Poles"), icon = select_poles_icon).eCnt = item.poles
            row = split.column()
            row.label(text = str(item.count))
            #row = split.column()
            #row.prop(item, "show")

        # 'GRID' layout type should be as compact as possible (typically a single icon!).
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon_value=icon)
            
class MESH_UL_polygonList(bpy.types.UIList):

    # Called for each drawn item.
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index, flt_flag):
        # 'DEFAULT' and 'COMPACT' layout types should usually use the same draw code.
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            split = layout.split(factor = 0.7, align = True)
            row = split.column()
            row.operator(MESH_OT_select_polygons.bl_idname, text = ("Select " + item.name), icon = select_polyogns_icon).eCnt = item.poles
            row = split.column()
            row.label(text = str(item.count))
            # row = split.column()
            # row.prop(item, "show")

        # 'GRID' layout type should be as compact as possible (typically a single icon!).
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon_value=icon)
    
class AnalyzerSubMenu(bpy.types.Menu):
    bl_idname = "EDIT_MT_analyzer_submenu"
    bl_label = "Mesh Analyzer"
    
    def draw(self, context):
        layout = self.layout
        
        layout.operator(MESH_OT_analyze_all.bl_idname, icon= analyze_all_icon)
        layout.operator(MESH_OT_create_report.bl_idname, icon=create_report_icon)
        layout.operator(MESH_OT_analyze.bl_idname, icon = analyze_poles_icon)
        layout.operator(MESH_OT_select_poles.bl_idname, icon = select_poles_icon)
        layout.operator(MESH_OT_FindDoubles.bl_idname, icon = find_doubles_icon)
        layout.operator(MESH_OT_RemoveDoubles.bl_idname, icon = remove_doubles_icon)
        layout.separator()
        layout.operator(MESH_OT_FindSingleEdges.bl_idname, icon = find_single_edges_icon)
        layout.operator(MESH_OT_FindNonManifoldEdges.bl_idname, icon = find_nonmanifolds_icon)
        layout.separator()
        layout.operator(MESH_OT_analyze_polygons.bl_idname, icon = analyze_polygons_icon)
        layout.operator(MESH_OT_select_polygons.bl_idname, icon = select_polyogns_icon)
    

class VIEW3D_MT_MeshAnalyzer(bpy.types.Menu):
    '''This pie menu shows all operators belonging to this add-on. Invoked by shortcut.
    '''
    bl_idname = "VIEW3D_MT_Mesh_Analyzer"
    bl_label = "MeshAnalyzer:"
    
    def draw(self,context):
        pie = self.layout.menu_pie()
        
        pie.operator(MESH_OT_analyze_all.bl_idname, icon = analyze_all_icon)
        pie.operator(MESH_OT_create_report.bl_idname, icon=create_report_icon)
        pie.operator(MESH_OT_analyze.bl_idname, icon = analyze_poles_icon)
        pie.operator(MESH_OT_FindDoubles.bl_idname, icon = remove_doubles_icon)
        pie.operator(MESH_OT_FindSingleEdges.bl_idname, icon = find_single_edges_icon)
        pie.operator(MESH_OT_FindNonManifoldEdges.bl_idname, icon = find_nonmanifolds_icon)
        pie.operator(MESH_OT_analyze_polygons.bl_idname, icon = analyze_polygons_icon)
    