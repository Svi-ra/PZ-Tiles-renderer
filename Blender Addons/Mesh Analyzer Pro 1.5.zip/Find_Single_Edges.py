# Copyright Tobias Stelzer 2020

# ##### BEGIN GPL LICENSE BLOCK #####
#    This file is part of MeshAnalyzerPro.
#
#    MeshAnalyzerPro is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MeshAnalyzerPro is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MeshAnalyzerPro.  If not, see <https://www.gnu.org/licenses/>.

import bpy
import bmesh

from .main import *

class MESH_OT_FindSingleEdges(bpy.types.Operator):
        '''Finds Edges that are not connected to faces in a mesh'''
        bl_idname = "mesh.find_singleedges"
        bl_label = "Find Single Edges"    
        bl_description = "Find single edges not connected to faces"
        bl_options = {'REGISTER'}

        @classmethod
        def poll(cls,context):
            return(context.mode == 'EDIT_MESH')
         
        def execute(self, context):
            main(find_single_edges,[], cntx = context)
            return{'FINISHED'}
             
        def invoke(self,context,event):
            result = main(find_single_edges,[], cntx = context)
            if result[0] == SUCCESS:
                return {'FINISHED'}
            else:
                self.report(type = {result[0]}, message = result[1])
                return ('FINISHED' if result[0] == WARNING else 'CANCELLED')

class MESH_OT_SelectSingleEdges(bpy.types.Operator):
        '''Selects Edges that are not connected to faces in a mesh'''
        bl_idname = "mesh.select_singleedges"
        bl_label = "Select Single Edges"    
        bl_description = "Selects single edges not connected to faces"
        bl_options = {'REGISTER'}

        @classmethod
        def poll(cls,context):
            return(context.mode == 'EDIT_MESH')
         
        def execute(self, context):
            main(select_single_edges,[], cntx = context)
            return{'FINISHED'}
             
        def invoke(self,context,event):
            result = main(select_single_edges,[], cntx = context)
            if result[0] == SUCCESS:
                return {'FINISHED'}
            else:
                self.report(type = {result[0]}, message = result[1])
                return ('FINISHED' if result[0] == WARNING else 'CANCELLED')


# Finds single Edges
def find_single_edges():
    selected = 0

    name = "single_edge_vertices"
    thisObject = bpy.context.active_object
    if name in thisObject.ListOfSingleEdgeIndices:
        vertList = thisObject.ListOfSingleEdgeVertices[name]
        vertIndexList = vertList.indexList
        vertIndexList.clear()
        edgeList = thisObject.ListOfSingleEdgeIndices[name]
        edgeIndexList = edgeList.indexList
        edgeIndexList.clear()
    else:
        vertList = thisObject.ListOfSingleEdgeVertices.add()
        vertList.name = name
        vertIndexList = vertList.indexList
        edgeList = thisObject.ListOfSingleEdgeIndices.add()
        edgeList.name = name
        edgeIndexList = edgeList.indexList
    
    # Get the active mesh
    activeMesh = bpy.context.object.data
    
    # BMesh Representation
    bm = bmesh.from_edit_mesh(activeMesh)
        
    # Edges
    edges = bm.edges[:]
    
    bm.select_mode = {'VERT','EDGE','FACE'}
    
    # Modify mesh here
    for edge in edges:
        if edge.is_wire:
            selected += 1
            edgeIndex = edgeIndexList.add()
            edgeIndex.index = edge.index
            vertIndex = vertIndexList.add()
            vertIndex.index1 = edge.verts[0].index
            vertIndex.index2 = edge.verts[1].index
    bpy.context.object.numberOfVertices = len(activeMesh.vertices)
    bpy.context.object.numberOfEdges = len(activeMesh.edges)
    bpy.context.object.numberOfFaces = len(activeMesh.polygons)
    thisObject.Recalc = False
    bpy.context.object.SingleEdgeCount = selected


# Finds single Edges
def select_single_edges():
    name = "single_edge_vertices"
    thisObject = bpy.context.active_object
    if name not in thisObject.ListOfSingleEdgeIndices:
        find_single_edges()
    
    # Prepare mesh
    bpy.ops.object.mode_set(mode = 'OBJECT')

    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_mode(type="EDGE")
    bpy.ops.mesh.select_all(action = 'DESELECT')
    bpy.ops.object.mode_set(mode = 'OBJECT')
    
    # Get the active mesh
    activeMesh = bpy.context.object.data
    
    # BMesh Representation
    bm = bmesh.new()
    bm.from_mesh(activeMesh)

    bm.select_mode = {'VERT', 'EDGE', 'FACE'}
    bm.edges.ensure_lookup_table()
    for index in thisObject.ListOfSingleEdgeIndices[name].indexList:
        bm.edges[index.index].select = True

    # make sure, edges and faces are also selected
    bm.select_flush_mode
    # Writing bmesh back to mesh (if applicable)
    bm.to_mesh(activeMesh)

    bm.free()
    bpy.ops.object.mode_set(mode = 'EDIT')