# Copyright Tobias Stelzer 2020

# ##### BEGIN GPL LICENSE BLOCK #####
#    This file is part of MeshAnalyzerPro.
#
#    MeshAnalyzerPro is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MeshAnalyzerPro is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MeshAnalyzerPro.  If not, see <https://www.gnu.org/licenses/>.

import bpy
from bpy.props import BoolProperty

from .Select_Poles import *
from .main import *
from .Analyze_Poles import *
from .Find_Doubles import *
from .Find_Single_Edges import *
from .Find_Nonmanifolds import *
from .Analyze_Polygons import *

# Operator classes
class MESH_OT_analyze_all(bpy.types.Operator):
    '''Analyzes a mesh and selects poles'''
    bl_idname = "mesh.analyze_all"
    bl_label = "Analyze All"    
    bl_description = "Analyzes everything in one step."
    bl_options = {'REGISTER'}
    
    @classmethod
    def poll(cls,context):
        return(context.mode == 'EDIT_MESH')
    
    def execute(self, context):
        main(analyze_all,[], cntx = context)
        return{'FINISHED'}
        
    def invoke(self,context,event):
        result = main(analyze_all,[], cntx = context)
        if result[0] == SUCCESS:
            return {'FINISHED'}
        else:
            self.report(type = {result[0]}, message = result[1])
            return ('FINISHED' if result[0] == WARNING else 'CANCELLED')
            
def analyze_all():
    '''Analyzes the mesh in terms of vertices, edges and faces.'''
    thisObject = bpy.context.object

    bpy.ops.mesh.analyze()
    bpy.ops.mesh.find_doubles()
    bpy.ops.mesh.find_singleedges()
    bpy.ops.mesh.find_nonmanifolds()
    bpy.ops.mesh.analyze_polygons()