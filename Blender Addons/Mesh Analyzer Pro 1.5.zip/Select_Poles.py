# Copyright Tobias Stelzer 2020

# ##### BEGIN GPL LICENSE BLOCK #####
#    This file is part of MeshAnalyzerPro.
#
#    MeshAnalyzerPro is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MeshAnalyzerPro is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MeshAnalyzerPro.  If not, see <https://www.gnu.org/licenses/>.

import bpy
import bmesh

from bpy.props import IntProperty, BoolProperty
from .main import *

class MESH_OT_select_poles(bpy.types.Operator):
    '''Selects poles'''
    bl_idname = "mesh.select_poles"
    bl_label = "Select Poles"    
    bl_description = "Selects pole with the selected number of edges"
    bl_options = {'REGISTER'}
        
    eCnt : IntProperty(name = "Edge Count",
                       description = "Number of Edges connected to one vertice",
                       default = 5,
                       min = 0)
    
    cnsdrBndr : BoolProperty(name = "Consider Boundary",
                        description = "Are vertices on the boundary considered?",
                        default = True)
    
    @classmethod
    def poll(cls,context):
        return(context.mode == 'EDIT_MESH')
    
    def execute(self, context):
        main(select_poles,[ self.eCnt, self.cnsdrBndr], cntx = context)
        return{'FINISHED'}
        
    def invoke(self,context,event):
        result = main(select_poles, [self.eCnt, self.cnsdrBndr] , cntx = context)
        if result[0] == SUCCESS:
            return {'FINISHED'}
        else:
            self.report(type = {result[0]}, message = result[1])
            return ('FINISHED' if result[0] == WARNING else 'CANCELLED')

def select_poles(edgeCount, considerBoundary):
    name = (str(edgeCount)+"-Pole")
    thisObject = bpy.context.active_object
    if name not in thisObject.ListOfPolesLists:
        return
    
    # Prepare mesh
    bpy.ops.object.mode_set(mode = 'OBJECT')

    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_mode(type="VERT")
    bpy.ops.mesh.select_all(action = 'DESELECT')
    bpy.ops.object.mode_set(mode = 'OBJECT')

    activeMesh = bpy.context.object.data
    
    # BMesh Representation
    bm = bmesh.new()
    bm.from_mesh(activeMesh)

    bm.select_mode = {'VERT', 'EDGE', 'FACE'}
    bm.verts.ensure_lookup_table()
    for index in thisObject.ListOfPolesLists[name].indexList:
        bm.verts[index.index].select = True

    # make sure, edges and faces are also selected
    bm.select_flush_mode
    # Writing bmesh back to mesh (if applicable)
    bm.to_mesh(activeMesh)

    bm.free()

    bpy.ops.object.mode_set(mode = 'EDIT')
    return