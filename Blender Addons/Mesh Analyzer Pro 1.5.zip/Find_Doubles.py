# Copyright Tobias Stelzer 2020

# ##### BEGIN GPL LICENSE BLOCK #####
#    This file is part of MeshAnalyzerPro.
#
#    MeshAnalyzerPro is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MeshAnalyzerPro is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MeshAnalyzerPro.  If not, see <https://www.gnu.org/licenses/>.

import bpy
import bmesh

from bpy.props import FloatProperty
from .main import *

class MESH_OT_FindDoubles(bpy.types.Operator):
        '''Analyzes a mesh for doubles'''
        bl_idname = "mesh.find_doubles"
        bl_label = "Find Doubles"    
        bl_description = "Finds Doubles with the specified distance"
        bl_options = {'REGISTER', 'UNDO'}
        
        distance : FloatProperty(name = "Max distance between doubles",
                       description = "The maximum allowed spacing between two vertices before they are considered doubles.",
                       default = 0.0001,
                       min = 0)
         
        @classmethod
        def poll(cls,context):
            return(context.mode == 'EDIT_MESH')
         
        def execute(self, context):
            main(find_doubles,[ self.distance], cntx = context)
            return{'FINISHED'}
             
        def invoke(self,context,event):
            result = main(find_doubles,[ self.distance], cntx = context)
            if result[0] == SUCCESS:
                return {'FINISHED'}
            else:
                self.report(type = {result[0]}, message = result[1])
                return ('FINISHED' if result[0] == WARNING else 'CANCELLED')    

class MESH_OT_SelectDoubles(bpy.types.Operator):
        '''Select all doubles in a mesh'''
        bl_idname = "mesh.delect_doubles"
        bl_label = "Select Doubles"   
        bl_description = "Selects Doubles with the specified distance"
        bl_options = {'REGISTER', 'UNDO'}

        distance : FloatProperty(name = "Max distance between doubles",
                       description = "The maximum allowed spacing between two vertices before they are considered doubles.",
                       default = 0.0001,
                       min = 0)
         
        @classmethod
        def poll(cls,context):
            return(context.mode == 'EDIT_MESH')
         
        def execute(self, context):
            main(select_doubles,[self.distance], cntx = context)
            return{'FINISHED'}
             
        def invoke(self,context,event):
            result = main(select_doubles,[self.distance], cntx = context)
            if result[0] == SUCCESS:
                return {'FINISHED'}
            else:
                self.report(type = {result[0]}, message = result[1])
                return ('FINISHED' if result[0] == WARNING else 'CANCELLED') 

def find_doubles(distance):

    name = "Doubles"
    thisObject = bpy.context.active_object
    if name in thisObject.ListOfDoubleIndices:
        list = thisObject.ListOfDoubleIndices[name]
        indexList = list.indexList
        indexList.clear()
    else:
        list = thisObject.ListOfDoubleIndices.add()
        list.name = name
        list.edgeCount = 0
        indexList = list.indexList
        indexList.clear()

        # Get the active mesh
    # Get the active mesh
    activeMesh = bpy.context.object.data
    
    # BMesh Representation
    bm = bmesh.from_edit_mesh(activeMesh)
    
    # Vertices
    vertices = bm.verts[:]
    
    doubles = bmesh.ops.find_doubles(bm, verts = vertices, dist = distance)
     
    double_verts = doubles['targetmap']
    
    for vertex in double_verts.values():
        vertIndex = indexList.add()
        vertIndex.index = vertex.index
        #vertex.select = True
    for vertex in double_verts:
        vertIndex = indexList.add()
        vertIndex.index = vertex.index
        #vertex.select = True
    
    # make sure, edges and faces are also selected
    #bm.select_flush_mode
    
    # Writing bmesh back to mesh (if applicable)
    #bm.to_mesh(activeMesh)
    bpy.context.object.numberOfVertices = len(activeMesh.vertices)
    bpy.context.object.numberOfEdges = len(activeMesh.edges)
    bpy.context.object.numberOfFaces = len(activeMesh.polygons)
    thisObject.Recalc = False
    
    thisObject.DoubleCnt = len(double_verts.keys())

def select_doubles(distance):
    name = "Doubles"
    thisObject = bpy.context.active_object
    if name not in thisObject.ListOfDoubleIndices:
        find_doubles(distance)
    
    # Prepare mesh
    bpy.ops.object.mode_set(mode = 'OBJECT')

    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_mode(type="VERT")
    bpy.ops.mesh.select_all(action = 'DESELECT')
    bpy.ops.object.mode_set(mode = 'OBJECT')

    activeMesh = bpy.context.object.data
    
    # BMesh Representation
    bm = bmesh.new()
    bm.from_mesh(activeMesh)

    bm.select_mode = {'VERT', 'EDGE', 'FACE'}
    bm.verts.ensure_lookup_table()
    for index in thisObject.ListOfDoubleIndices[name].indexList:
        bm.verts[index.index].select = True

    # make sure, edges and faces are also selected
    bm.select_flush_mode
    # Writing bmesh back to mesh (if applicable)
    bm.to_mesh(activeMesh)

    bm.free()

    bpy.ops.object.mode_set(mode = 'EDIT')
    return