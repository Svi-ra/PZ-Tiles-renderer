# Copyright Tobias Stelzer 2020

# ##### BEGIN GPL LICENSE BLOCK #####
#    This file is part of MeshAnalyzerPro.
#
#    MeshAnalyzerPro is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MeshAnalyzerPro is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MeshAnalyzerPro.  If not, see <https://www.gnu.org/licenses/>.

import bpy
from .main import *
from . import Analyze_All
from datetime import datetime

class MESH_OT_create_report(bpy.types.Operator):
    '''Creates a report for this object'''
    bl_idname = "mesh.create_report"
    bl_label = "Create Mesh Report"    
    bl_description = "Creates a report for this object"
    bl_options = {'REGISTER'}

    filepath : bpy.props.StringProperty(subtype="FILE_PATH")
    
    @classmethod
    def poll(cls,context):
        return(context.mode == 'EDIT_MESH')
    
    def execute(self, context):
        Analyze_All.analyze_all()
        main(create_report,[self], cntx = context)
        return{'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

def create_report(self):
    obj = bpy.context.active_object
    report = open(self.filepath,'w')
    report.write("Mesh Analyzer Pro - Report:" + '\n')
    report.write("-----------------------------\n")
    # datetime object containing current date and time
    now = datetime.now()
    # dd.mm.YYYY H:M:S
    dt_string = now.strftime("%d.%m.%Y %H:%M:%S")
    #print("date and time =", dt_string)	
    report.write("Date: "+ dt_string + '\n')
    report.write("-----------------------------\n")
    report.write("Object Name: "+ obj.name + '\n')
    report.write("-----------------------------\n")
    report.write("Statistics:"+'\n')
    report.write('\n')
    report.write("Vertex Count: "+ str(len(obj.data.vertices)) + '\n')
    report.write("Edge Count: "+ str(len(obj.data.edges)) + '\n')
    report.write("Face Count: "+ str(len(obj.data.polygons)) + '\n')
    report.write("-----------------------------\n")  
    report.write("Vertices:" + '\n')
    report.write('\n')
    report.write("List of Poles:\n")
    for pole in obj.ListOfPoles:
        name = (str(pole.poles)+"-Pole")
        report.write(name + ": " + str(pole.count) + '\n')  

    report.write('\n')
    report.write("Double count: " + str(obj.DoubleCnt) + '\n')
    report.write("-----------------------------\n")
    report.write("Edges:"'\n')
    report.write('\n')
    report.write("Single Edges: " + str(obj.SingleEdgeCount) + '\n')
    report.write('\n')
    report.write("Non-manifold Edges: " + str(obj.NonManifoldEdges) + '\n')
    report.write("-----------------------------\n")
    report.write("Polygons:"'\n')
    report.write('\n')
    for face in obj.ListOfPolygons:
        if face.poles == 3:
            name = "Tris"
        else:
            if face.poles == 4:
                name = "Quads"
            else:        
                name = (str(face.poles)+"-Gon")
        report.write(name + ": " + str(face.count) + '\n')  
    report.write("-----------------------------\n")
    report.close()
    return