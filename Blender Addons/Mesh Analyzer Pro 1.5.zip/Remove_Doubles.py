# Copyright Tobias Stelzer 2020

# ##### BEGIN GPL LICENSE BLOCK #####
#    This file is part of MeshAnalyzerPro.
#
#    MeshAnalyzerPro is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MeshAnalyzerPro is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MeshAnalyzerPro.  If not, see <https://www.gnu.org/licenses/>.

import bpy
import bmesh

from bpy.props import FloatProperty
from bpy.props import BoolProperty
from .main import *

class MESH_OT_RemoveDoubles(bpy.types.Operator):
        '''Removes doubles from a mesh'''
        bl_idname = "mesh.remove_my_doubles"
        bl_label = "Remove Doubles"    
        bl_description = "Removes Doubles with the specified distance"
        bl_options = {'REGISTER', 'UNDO'}
        
        distance : FloatProperty(name = "Max distance between doubles",
                       description = "The maximum allowed spacing between two vertices before they are considered doubles.",
                       default = 0.0001,
                       min = 0)
                       
        selected : BoolProperty(name = "Only consider selected.",
                        description = "Remove only doubles from the selection set.",
                        default = True        
                        )
        
        @classmethod
        def poll(cls,context):
            return(context.mode == 'EDIT_MESH')
         
        def execute(self, context):
            main(remove_doubles,[ self.distance, self.selected], cntx = context)
            return{'FINISHED'}
             
        def invoke(self,context,event):
            result = main(remove_doubles,[ self.distance, self.selected], cntx = context)
            if result[0] == SUCCESS:
                return {'FINISHED'}
            else:
                self.report(type = {result[0]}, message = result[1])
                return ('FINISHED' if result[0] == WARNING else 'CANCELLED')    

# Remove Doubles
def remove_doubles(distance, sel):

    bpy.ops.object.mode_set(mode = 'OBJECT')
    # Get the active mesh
    activeMesh = bpy.context.object.data
    
    # BMesh Representation
    bm = bmesh.new()
    bm.from_mesh(activeMesh)
    
    # Vertices
    if sel == True:
        vertices = [vert for vert in bm.verts[:] if vert.select == True]
    else:
        vertices = bm.verts[:]
        
    bmesh.ops.remove_doubles(bm, verts = vertices, dist = distance)
    
    vertices = bm.verts[:]
    
    doubles = bmesh.ops.find_doubles(bm, verts = vertices, dist = distance)
    
    thisObject = bpy.context.object
    
    double_verts = doubles['targetmap']
    
    thisObject.DoubleCnt = len(double_verts.keys())
    
    # make sure, edges and faces are also selected
    bm.select_flush_mode
    
    # Writing bmesh back to mesh (if applicable)
    bm.to_mesh(activeMesh)
    bm.free()
    bpy.ops.object.mode_set(mode = 'EDIT')