# Copyright Tobias Stelzer 2020

# ##### BEGIN GPL LICENSE BLOCK #####
#    This file is part of MeshAnalyzerPro.
#
#    MeshAnalyzerPro is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MeshAnalyzerPro is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MeshAnalyzerPro.  If not, see <https://www.gnu.org/licenses/>.

import bpy
import bmesh

from .main import *

class MESH_OT_FindNonManifoldEdges(bpy.types.Operator):
        '''Finds Edges that are non-manifold'''
        bl_idname = "mesh.find_nonmanifolds"
        bl_label = "Find Non-manifold Edges"    
        bl_description = "Find non-manifold edges. Useful for finding geometry inside the mesh or overlaaying faces."
        bl_options = {'REGISTER'}

        @classmethod
        def poll(cls,context):
            return(context.mode == 'EDIT_MESH')
         
        def execute(self, context):
            main(find_non_manifold_edges,[], cntx = context)
            return{'FINISHED'}
             
        def invoke(self,context,event):
            result = main(find_non_manifold_edges,[], cntx = context)
            if result[0] == SUCCESS:
                return {'FINISHED'}
            else:
                self.report(type = {result[0]}, message = result[1])
                return ('FINISHED' if result[0] == WARNING else 'CANCELLED')    

class MESH_OT_SelectNonManifoldEdges(bpy.types.Operator):
        '''Selects Edges that are non-manifold'''
        bl_idname = "mesh.select_nonmanifolds"
        bl_label = "Select Non-manifold Edges"    
        bl_description = "Select non-manifold edges."
        bl_options = {'REGISTER'}

        @classmethod
        def poll(cls,context):
            return(context.mode == 'EDIT_MESH')
         
        def execute(self, context):
            main(select_non_manifold_edges,[], cntx = context)
            return{'FINISHED'}
             
        def invoke(self,context,event):
            result = main(select_non_manifold_edges,[], cntx = context)
            if result[0] == SUCCESS:
                return {'FINISHED'}
            else:
                self.report(type = {result[0]}, message = result[1])
                return ('FINISHED' if result[0] == WARNING else 'CANCELLED')    

# Finds inside Faces
def find_non_manifold_edges():
    
    selected = 0
    name = "non_manifold_edge_vertices"
    thisObject = bpy.context.active_object
    if name in thisObject.ListOfNonManifoldEdgeIndices:
        vertList = thisObject.ListOfNonManifoldEdgeVertices[name]
        vertIndexList = vertList.indexList
        vertIndexList.clear()
        edgeList = thisObject.ListOfNonManifoldEdgeIndices[name]
        edgeIndexList = edgeList.indexList
        edgeIndexList.clear()
    else:
        vertList = thisObject.ListOfNonManifoldEdgeVertices.add()
        vertList.name = name
        vertIndexList = vertList.indexList
        edgeList = thisObject.ListOfNonManifoldEdgeIndices.add()
        edgeList.name = name
        edgeIndexList = edgeList.indexList
    
    # Get the active mesh
    activeMesh = bpy.context.object.data
    
    # BMesh Representation
    bm = bmesh.from_edit_mesh(activeMesh)
        
    # Edges
    edges = bm.edges[:]
    
    bm.select_mode = {'VERT','EDGE','FACE'}
    
    # Modify mesh here
    for edge in edges:
        if edge.is_manifold == False:# and edge.is_boundary == False:
            selected += 1
            edgeIndex = edgeIndexList.add()
            edgeIndex.index = edge.index
            vertIndex = vertIndexList.add()
            vertIndex.index1 = edge.verts[0].index
            vertIndex.index2 = edge.verts[1].index
    bpy.context.object.numberOfVertices = len(activeMesh.vertices)
    bpy.context.object.numberOfEdges = len(activeMesh.edges)
    bpy.context.object.numberOfFaces = len(activeMesh.polygons)
    thisObject.Recalc = False
    bpy.context.object.NonManifoldEdges = selected

# Finds inside Faces
def select_non_manifold_edges():
    name = "non_manifold_edge_vertices"
    thisObject = bpy.context.active_object
    if name not in thisObject.ListOfNonManifoldEdgeIndices:
        find_non_manifold_edges()
    
    # Prepare mesh
    bpy.ops.object.mode_set(mode = 'OBJECT')

    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_mode(type="EDGE")
    bpy.ops.mesh.select_all(action = 'DESELECT')
    bpy.ops.object.mode_set(mode = 'OBJECT')
    
    # Get the active mesh
    activeMesh = bpy.context.object.data
    
    # BMesh Representation
    bm = bmesh.new()
    bm.from_mesh(activeMesh)

    bm.select_mode = {'VERT', 'EDGE', 'FACE'}
    bm.edges.ensure_lookup_table()
    for index in thisObject.ListOfNonManifoldEdgeIndices[name].indexList:
        bm.edges[index.index].select = True

    # make sure, edges and faces are also selected
    bm.select_flush_mode
    # Writing bmesh back to mesh (if applicable)
    bm.to_mesh(activeMesh)

    bm.free()
    bpy.ops.object.mode_set(mode = 'EDIT')