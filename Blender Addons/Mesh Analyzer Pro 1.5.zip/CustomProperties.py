# Copyright Tobias Stelzer 2020

# ##### BEGIN GPL LICENSE BLOCK #####
#    This file is part of MeshAnalyzerPro.
#
#    MeshAnalyzerPro is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MeshAnalyzerPro is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MeshAnalyzerPro.  If not, see <https://www.gnu.org/licenses/>.

import bpy

from bpy.props import IntProperty, CollectionProperty, StringProperty, FloatVectorProperty, BoolProperty

# Define custom Property group        
class MeshAnalyzerObjectInfos(bpy.types.PropertyGroup):
    poles : IntProperty(name = "Number of Edges", description = "Number of Edges connected to a vert or a face",
                            default = 0, min = 0)
    count : IntProperty(name = "Count", description = "How many verts of this pole or polygon type are there.",
                            default = 0, min = 0)
    show : BoolProperty(name = "show", description="Show this pole in overlay.", default=True)
                          
class VertexIndexProp(bpy.types.PropertyGroup):
    index : IntProperty()

class IndexListProp(bpy.types.PropertyGroup):
    indexList : CollectionProperty(type = VertexIndexProp)
    name : StringProperty()
    edgeCount : IntProperty()

class EdgeVerticesIndexProp(bpy.types.PropertyGroup):
    index1 : IntProperty()
    index2 : IntProperty()

class EdgeIndexListProp(bpy.types.PropertyGroup):
    indexList : CollectionProperty(type = EdgeVerticesIndexProp)
    name : StringProperty()

class FaceVerticesIndexProp(bpy.types.PropertyGroup):
    index1 : IntProperty()
    index2 : IntProperty()
    index3 : IntProperty()
    offset : FloatVectorProperty()

class FaceIndexListProp(bpy.types.PropertyGroup):
    indexList : CollectionProperty(type = FaceVerticesIndexProp)
    name : StringProperty()
    count : IntProperty()