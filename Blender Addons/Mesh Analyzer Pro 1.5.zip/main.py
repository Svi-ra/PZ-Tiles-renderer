# Copyright Tobias Stelzer 2020

# ##### BEGIN GPL LICENSE BLOCK #####
#    This file is part of MeshAnalyzerPro.
#
#    MeshAnalyzerPro is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MeshAnalyzerPro is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MeshAnalyzerPro.  If not, see <https://www.gnu.org/licenses/>.

import bpy
import traceback

# possible results
INPUT_ERR = 'ERROR_INVALID_CONTEXT'
ERROR = 'ERROR'
SUCCESS = 'OK'
WARNING = 'WARNING' 

def main(method,args, cntx = None):
    ''' Checks conditions for the analyze function.
    @returns (list): return message with [<flag>, Optional_Details]
    '''
     
    try:
        if cntx == None: cntx = bpy.context 
        activeObject = cntx.object
        
        if activeObject.type != 'MESH':
            return[INPUT_ERR, "Cannot execute: target object %s is not a mesh" % activeObject.name]
        else:
            if activeObject.library != None or activeObject.data.library != None:
                return[INPUT_ERR, "Target mesh %s can't be linked" % activeObject.name]
            else:
                # Register changes to object
                bpy.ops.object.mode_set(mode = 'OBJECT')
                bpy.ops.object.mode_set(mode = 'EDIT')  
                method(*args)
                return [SUCCESS]
    
    except Exception as err:
        traceback.print_exc()
        
        cntx_msg = ""
        if 'activeObject' in locals: cntx_msg += "occured for object: '%s'" % activeObject.name
        
        return [ERROR, "%s %s" % (str(err),cntx_msg)]

  