# Copyright Tobias Stelzer 2020

# ##### BEGIN GPL LICENSE BLOCK #####
#    This file is part of MeshAnalyzerPro.
#
#    MeshAnalyzerPro is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MeshAnalyzerPro is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MeshAnalyzerPro.  If not, see <https://www.gnu.org/licenses/>.

import bpy
import bmesh

from mathutils.geometry import tessellate_polygon as tessellate

from bpy.props import IntProperty
from .main import *

class MESH_OT_find_polygons(bpy.types.Operator):
    '''Finds polygons'''
    bl_idname = "mesh.find_polygons"
    bl_label = "Find Polygon"    
    bl_description = "Finds polygon with the selected number of edges"
    bl_options = {'REGISTER'}
        
    eCnt : IntProperty(name = "Edge Count",
                       description = "Number of Edges adjacent to a face",
                       default = 4,
                       min = 0)
    
    @classmethod
    def poll(cls,context):
        return(context.mode == 'EDIT_MESH')
    
    def execute(self, context):
        main(find_ngons,[ self.eCnt], cntx = context)
        return{'FINISHED'}
        
    def invoke(self,context,event):
        result = main(find_ngons, [self.eCnt] , cntx = context)
        if result[0] == SUCCESS:
            return {'FINISHED'}
        else:
            self.report(type = {result[0]}, message = result[1])
            return ('FINISHED' if result[0] == WARNING else 'CANCELLED')

class MESH_OT_select_polygons(bpy.types.Operator):
    '''Selects polygons'''
    bl_idname = "mesh.select_polygons"
    bl_label = "Select Polygon"    
    bl_description = "Selects polygon with the selected number of edges"
    bl_options = {'REGISTER'}
        
    eCnt : IntProperty(name = "Edge Count",
                       description = "Number of Edges adjacent to a face",
                       default = 4,
                       min = 0)
    
    @classmethod
    def poll(cls,context):
        return(context.mode == 'EDIT_MESH')
    
    def execute(self, context):
        main(select_ngons,[ self.eCnt], cntx = context)
        return{'FINISHED'}
        
    def invoke(self,context,event):
        result = main(select_ngons, [self.eCnt] , cntx = context)
        if result[0] == SUCCESS:
            return {'FINISHED'}
        else:
            self.report(type = {result[0]}, message = result[1])
            return ('FINISHED' if result[0] == WARNING else 'CANCELLED')
        

def select_ngons(fcount):
    if fcount == 3:
        name = "Tris"
    else:
        if fcount == 4:
            name = "Quads"
        else:        
            name = (str(fcount)+"-Gon")
    thisObject = bpy.context.active_object
        
    # Prepare mesh
    bpy.ops.object.mode_set(mode = 'OBJECT')

    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_mode(type="FACE")
    bpy.ops.mesh.select_all(action = 'DESELECT')
    bpy.ops.object.mode_set(mode = 'OBJECT')
    
    # Get the active mesh
    activeMesh = bpy.context.object.data
    
    # BMesh Representation
    bm = bmesh.new()
    bm.from_mesh(activeMesh)
    
    # Vertices
    faces = bm.faces[:]
    
    bm.select_mode = {'VERT', 'EDGE', 'FACE'}
    bm.faces.ensure_lookup_table()
    for index in thisObject.ListOfnGonsLists[name].indexList:
        bm.faces[index.index].select = True
    
    # make sure, edges and faces are also selected
    bm.select_flush_mode
    
    # Writing bmesh back to mesh (if applicable)
    bm.to_mesh(activeMesh)
    bm.free()
    bpy.ops.object.mode_set(mode = 'EDIT')