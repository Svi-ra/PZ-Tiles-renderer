# Copyright Tobias Stelzer 2020

# ##### BEGIN GPL LICENSE BLOCK #####
#    This file is part of MeshAnalyzerPro.
#
#    MeshAnalyzerPro is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MeshAnalyzerPro is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MeshAnalyzerPro.  If not, see <https://www.gnu.org/licenses/>.

import bpy

from .Select_Polygons import *
from .main import *

class MESH_OT_analyze_polygons(bpy.types.Operator):
    '''Analyzes a mesh for polyogns'''
    bl_idname = "mesh.analyze_polygons"
    bl_label = "Analyze Polygons"    
    bl_description = "Analyzes the mesh for Polygons"
    bl_options = {'REGISTER'}
    
    vertexGroupName = "-Gon"

    @classmethod
    def poll(cls,context):
        return(context.mode == 'EDIT_MESH')
    
    def execute(self, context):
        main(analyze_ngons,[], cntx = context)
        return{'FINISHED'}
        
    def invoke(self,context,event):
        result = main(analyze_ngons,[], cntx = context)
        if result[0] == SUCCESS:
            return {'FINISHED'}
        else:
            self.report(type = {result[0]}, message = result[1])
            return ('FINISHED' if result[0] == WARNING else 'CANCELLED')
            
def analyze_ngons():

    thisObject = bpy.context.active_object
    thisObject.ListOfPolygons.clear()
    thisObject.ListOfnGonsLists.clear()
    thisObject.ListOfnGnonVertices.clear()
        
    # Get the active mesh
    activeMesh = bpy.context.object.data
    
    # BMesh Representation
    bm = bmesh.from_edit_mesh(activeMesh)
    
    # Vertices
    faces = bm.faces[:]

    ngons = {}
       
    # Modify mesh here
    for face in faces:
        key = str(len(face.edges))
        if (ngons.get(key) is None):
            ngons[key] = [face.index]
        else:
            ngons[key].append(face.index)
    

    for key in sorted(ngons):
        value = ngons[key]
        if int(key) == 3:
            name = "Tris"
        else:
            if int(key) == 4:
                name = "Quads"
            else:
                name = (key+MESH_OT_analyze_polygons.vertexGroupName)
    
        if name in thisObject.ListOfnGonsLists:
            list = thisObject.ListOfnGonsLists[name]
            indexList = list.indexList
            indexList.clear()
            vertList = thisObject.ListOfnGnonVertices[name]
            vertIndexList = vertList.indexList
            vertIndexList.clear()
        else:
            list = thisObject.ListOfnGonsLists.add()
            list.name = name
            list.edgeCount = int(key)
            indexList = list.indexList
            indexList.clear()
            vertList = thisObject.ListOfnGnonVertices.add()
            vertList.name = name
            vertList.count = int(key)
            vertIndexList = vertList.indexList

        for item in value:
            faceIndex = indexList.add()
            faceIndex.index = item
            coords = [v.co for v in faces[item].verts]
            indices = [v.index for v in faces[item].verts]
            normal = faces[item].normal
            for tri in tessellate([coords]):
                triList = vertIndexList.add()
                triList.index1 = indices[tri[0]]
                triList.index2 = indices[tri[1]]
                triList.index3 = indices[tri[2]]
                triList.offset = normal

        newListItem = thisObject.ListOfPolygons.add()
        newListItem.poles = int(key)
        newListItem.count = len(value)
        newListItem.name = name

  
    bpy.context.object.numberOfVertices = len(activeMesh.vertices)
    bpy.context.object.numberOfEdges = len(activeMesh.edges)
    bpy.context.object.numberOfFaces = len(activeMesh.polygons)
    thisObject.Recalc = False      